import os
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
from database import load_data

def generate_gantt_chart(project_id):
    """Генерирует и отображает диаграмму Ганта для проекта"""
    try:
        data = load_data()
        
        # Находим проект
        project = next((p for p in data["projects"] if p["id"] == project_id), None)
        if not project:
            return False, "Проект не найден"
        
        # Получаем задачи проекта
        project_tasks = [t for t in data.get("tasks", []) if t.get("project_id") == project_id]
        if not project_tasks:
            return False, "В проекте нет задач для построения диаграммы"
        
        # Создаем данные для диаграммы
        tasks_data = []
        for task in project_tasks:
            if task.get('deadline') and task.get('status') not in ['выполнено', 'не_выполнено']:
                try:
                    deadline = datetime.strptime(task['deadline'], '%Y-%m-%d')
                    # Используем дату начала проекта как старт для задачи
                    start_date = datetime.strptime(project['start_date'], '%Y-%m-%d') if project.get('start_date') else datetime.now()
                    
                    tasks_data.append({
                        'task': task['title'],
                        'start': start_date,
                        'end': deadline,
                        'status': task.get('status', 'черновик')
                    })
                except ValueError:
                    continue
        
        if not tasks_data:
            return False, "Нет задач с корректными датами для построения диаграммы"
        
        # Создаем диаграмму
        plt.figure(figsize=(12, 6))
        
        colors = {
            'черновик': 'lightgray',
            'на_рассмотрении': 'lightblue', 
            'в_работе': 'lightgreen',
            'выполнено': 'green',
            'не_выполнено': 'red'
        }
        
        for i, task_data in enumerate(tasks_data):
            color = colors.get(task_data['status'], 'lightgray')
            plt.barh(task_data['task'], 
                    (task_data['end'] - task_data['start']).days,
                    left=task_data['start'],
                    color=color,
                    alpha=0.6,
                    label=task_data['status'] if i == 0 else "")
        
        # Настраиваем внешний вид
        plt.xlabel('Дата')
        plt.ylabel('Задачи')
        plt.title(f'Диаграмма Ганта: {project["name"]}')
        
        # Форматируем даты
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        plt.gca().xaxis.set_major_locator(mdates.WeekdayLocator(interval=1))
        plt.gcf().autofmt_xdate()
        
        # Добавляем легенду
        handles = [plt.Rectangle((0,0),1,1, color=colors[status]) for status in colors]
        plt.legend(handles, colors.keys(), title='Статусы')
        
        # Делаем диаграмму интерактивной
        plt.tight_layout()
        plt.show()
        
        return True, "Диаграмма Ганта отображена"
        
    except Exception as e:
        return False, f"Ошибка при построении диаграммы: {str(e)}"

def generate_comprehensive_report(user=None):
    """Генерирует комплексный отчет"""
    data = load_data()
    
    report = "КОМПЛЕКСНЫЙ ОТЧЕТ СИСТЕМЫ\n"
    report += "=" * 50 + "\n\n"
    
    # Статистика проектов
    total_projects = len(data["projects"])
    completed_projects = len([p for p in data["projects"] if p.get("status") in ["выполнено", "не_выполнено"]])
    active_projects = total_projects - completed_projects
    
    report += "СТАТИСТИКА ПРОЕКТОВ:\n"
    report += f"Всего проектов: {total_projects}\n"
    report += f"Активных проектов: {active_projects}\n"
    report += f"Завершенных проектов: {completed_projects}\n\n"
    
    # Статистика по статусам проектов
    status_stats = {}
    for project in data["projects"]:
        status = project.get("status", "черновик")
        status_stats[status] = status_stats.get(status, 0) + 1
    
    report += "Статистика по статусам проектов:\n"
    for status, count in status_stats.items():
        report += f"  {status}: {count}\n"
    report += "\n"
    
    # Статистика задач
    total_tasks = len(data.get("tasks", []))
    completed_tasks = len([t for t in data.get("tasks", []) if t.get("status") in ["выполнено", "не_выполнено"]])
    active_tasks = total_tasks - completed_tasks
    
    report += "СТАТИСТИКА ЗАДАЧ:\n"
    report += f"Всего задач: {total_tasks}\n"
    report += f"Активных задач: {active_tasks}\n"
    report += f"Завершенных задач: {completed_tasks}\n\n"
    
    # Статистика работ
    total_works = len(data.get("works", []))
    completed_works = len([w for w in data.get("works", []) if w.get("status") in ["выполнено", "не_выполнено"]])
    active_works = total_works - completed_works
    
    report += "СТАТИСТИКА РАБОТ:\n"
    report += f"Всего работ: {total_works}\n"
    report += f"Активных работ: {active_works}\n"
    report += f"Завершенных работ: {completed_works}\n\n"
    
    # Пользователи по ролям
    from auth import ROLES
    role_stats = {}
    for user_data in data["users"]:
        role = user_data.get("role", "неизвестно")
        role_stats[role] = role_stats.get(role, 0) + 1
    
    report += "ПОЛЬЗОВАТЕЛИ ПО РОЛЯМ:\n"
    for role, count in role_stats.items():
        role_name = ROLES.get(role, role)
        report += f"  {role_name}: {count}\n"
    
    return report

def check_overdue_tasks():
    """Проверяет просроченные задачи"""
    data = load_data()
    from datetime import datetime
    today = datetime.now().date()
    
    overdue_tasks = []
    for task in data.get("tasks", []):
        if task.get("deadline") and task.get("status") not in ["выполнено", "не_выполнено"]:
            try:
                deadline = datetime.strptime(task["deadline"], '%Y-%m-%d').date()
                if deadline < today:
                    overdue_tasks.append(task)
            except ValueError:
                continue
    
    return overdue_tasks

def export_report_to_file(report_text, filename):
    """Экспортирует отчет в файл"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(report_text)
        return True, f"Отчет успешно экспортирован в {filename}"
    except Exception as e:
        return False, f"Ошибка при экспорте отчета: {str(e)}"

def check_deadlines(user=None):
    """Проверяет просроченные задачи и проекты (совместимость со старой версией)"""
    data = load_data()
    from datetime import datetime
    today = datetime.now().date()
    
    report = "=== ПРОВЕРКА СРОКОВ ===\n\n"
    
    # Проверяем проекты
    overdue_projects = []
    for project in data["projects"]:
        if project.get("planned_end") and project["status"] not in ["выполнено", "не_выполнено"]:
            try:
                deadline = datetime.strptime(project["planned_end"], '%Y-%m-%d').date()
                if deadline < today:
                    overdue_projects.append(project)
            except ValueError:
                continue
    
    if overdue_projects:
        report += "⚠️  ПРОСРОЧЕННЫЕ ПРОЕКТЫ:\n"
        for project in overdue_projects:
            report += f"   - Проект '{project['name']}' (срок: {project['planned_end']})\n"
    else:
        report += "✅ Просроченных проектов нет\n"
    
    report += "\n"
    
    # Проверяем задачи
    overdue_tasks = []
    for task in data.get("tasks", []):
        if task.get("deadline") and task.get("status") not in ["выполнено", "не_выполнено"]:
            try:
                deadline = datetime.strptime(task["deadline"], '%Y-%m-%d').date()
                if deadline < today:
                    overdue_tasks.append(task)
            except ValueError:
                continue
    
    if overdue_tasks:
        report += "⚠️  ПРОСРОЧЕННЫЕ ЗАДАЧИ:\n"
        for task in overdue_tasks:
            report += f"   - Задача '{task['title']}' (срок: {task['deadline']})\n"
    else:
        report += "✅ Просроченных задач нет\n"
    
    # Всегда возвращаем результат
    return report