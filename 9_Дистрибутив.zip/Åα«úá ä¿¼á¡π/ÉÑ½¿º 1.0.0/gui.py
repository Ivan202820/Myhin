import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import json
import os
from datetime import datetime, timedelta
import hashlib
import calendar
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# Константы
DB_FILE = "data.json"
ATTACHMENTS_DIR = "attachments"

# Права доступа
AVAILABLE_PERMISSIONS = {
    "view_projects": "Просмотр проектов",
    "edit_projects": "Редактирование проектов", 
    "delete_projects": "Удаление проектов",
    "change_project_status": "Изменение статуса проектов",
    "view_tasks": "Просмотр задач",
    "edit_tasks": "Редактирование задач",
    "delete_tasks": "Удаление задач", 
    "change_task_status": "Изменение статуса задач",
    "view_works": "Просмотр работ",
    "edit_works": "Редактирование работ",
    "change_work_status": "Изменение статуса работ",
    "manage_users": "Управление пользователями",
    "view_reports": "Просмотр отчетов",
    "edit_reports": "Редактирование отчетов",
    "force_edit": "Принудительное редактирование (админ)",
    "manage_attachments": "Управление вложениями"
}

# Статусы
PROJECT_STATUSES = ["черновик", "на_рассмотрении", "в_работе", "выполнено", "не_выполнено"]
TASK_STATUSES = ["черновик", "на_рассмотрении", "в_работе", "выполнено", "не_выполнено"] 
WORK_STATUSES = ["черновик", "на_рассмотрении", "в_работе", "выполнено", "не_выполнено"]
PRIORITIES = ["низкий", "средний", "высокий"]

# Роли пользователей
ROLES = {
    "администратор": "Администратор системы",
    "руководитель_проекта": "Руководитель проекта", 
    "ответственный_исполнитель": "Ответственный исполнитель",
    "исполнитель": "Исполнитель"
}

# Функции базы данных
def get_default_permissions(role):
    """Возвращает права по умолчанию для роли"""
    base_permissions = {
        "view_projects": False,
        "edit_projects": False,
        "delete_projects": False,
        "change_project_status": False,
        "view_tasks": False,
        "edit_tasks": False,
        "delete_tasks": False,
        "change_task_status": False,
        "view_works": False,
        "edit_works": False,
        "change_work_status": False,
        "manage_users": False,
        "view_reports": False,
        "edit_reports": False,
        "force_edit": False,
        "manage_attachments": False
    }
    
    if role == "администратор":
        base_permissions = {key: True for key in base_permissions}
    elif role == "руководитель_проекта":
        base_permissions.update({
            "view_projects": True, "edit_projects": True, "change_project_status": True,
            "view_tasks": True, "edit_tasks": True, "change_task_status": True,
            "view_works": True, "view_reports": True, "edit_reports": True,
            "manage_attachments": True
        })
    elif role == "ответственный_исполнитель":
        base_permissions.update({
            "view_projects": True, "view_tasks": True, "edit_tasks": True,
            "change_task_status": True, "view_works": True, "edit_works": True,
            "change_work_status": True, "view_reports": True,
            "manage_attachments": True
        })
    elif role == "исполнитель":
        base_permissions.update({
            "view_projects": True, "view_tasks": True, "view_works": True,
            "change_work_status": True
        })
    
    return base_permissions

def create_initial_data():
    """Создает начальные данные с пользователями"""
    from auth import hash_password
    
    default_data = {
        "users": [
            {
                "username": "admin",
                "password": hash_password("admin"),
                "role": "администратор",
                "full_name": "Главный Администратор",
                "is_active": True,
                "permissions": get_default_permissions("администратор")
            },
            {
                "username": "manager1",
                "password": hash_password("manager1"),
                "role": "руководитель_проекта", 
                "full_name": "Иванов Петр Сергеевич",
                "is_active": True,
                "permissions": get_default_permissions("руководитель_проекта")
            },
            {
                "username": "resp1",
                "password": hash_password("resp1"),
                "role": "ответственный_исполнитель",
                "full_name": "Сидорова Анна Владимировна",
                "is_active": True,
                "permissions": get_default_permissions("ответственный_исполнитель")
            }
        ],
        "projects": [
            {
                "id": 1,
                "name": "Разработка веб-сайта",
                "client": "ООО 'ТехноПро'",
                "start_date": "2024-01-15",
                "planned_end": "2024-06-20",
                "actual_end": "",
                "manager": "manager1",
                "cost": 500000.0,
                "status": "в_работе",
                "custom_fields": {},
                "attachments": []
            }
        ],
        "tasks": [
            {
                "id": 1,
                "project_id": 1,
                "title": "Дизайн интерфейса",
                "description": "Создание дизайн-макетов для веб-сайта",
                "deadline": "2024-03-15",
                "priority": "высокий",
                "responsible": "resp1",
                "status": "в_работе",
                "custom_fields": {},
                "materials": [],
                "attachments": []
            }
        ],
        "works": [
            {
                "id": 1,
                "task_id": 1,
                "title": "Создание прототипа",
                "description": "Разработка wireframe и прототипа сайта",
                "parameters": "3 основных страницы",
                "executor": "resp1",
                "status": "выполнено",
                "created_by": "resp1",
                "attachments": []
            }
        ],
        "notifications": []
    }
    return default_data

def load_data():
    if not os.path.exists(DB_FILE):
        data = create_initial_data()
        save_data(data)
        return data
    
    with open(DB_FILE, "r", encoding='utf-8') as f:
        data = json.load(f)
    return data

def save_data(data):
    with open(DB_FILE, "w", encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def get_user_related_data(user):
    """Возвращает данные, связанные с пользователем (для исполнителей)"""
    data = load_data()
    
    # Если пользователь администратор или имеет полные права, возвращаем все данные
    if user["role"] == "администратор" or user["permissions"].get("force_edit", False):
        return data
    
    # Для исполнителей фильтруем данные
    if user["role"] == "исполнитель":
        # Получаем работы, где пользователь является исполнителем
        user_works = [work for work in data.get("works", []) if work.get("executor") == user["username"]]
        
        # Получаем ID задач из работ пользователя
        user_task_ids = list(set([work["task_id"] for work in user_works]))
        
        # Получаем задачи пользователя
        user_tasks = [task for task in data.get("tasks", []) if task["id"] in user_task_ids]
        
        # Получаем ID проектов из задач пользователя
        user_project_ids = list(set([task["project_id"] for task in user_tasks]))
        
        # Фильтруем проекты
        filtered_projects = [project for project in data["projects"] if project["id"] in user_project_ids]
        
        # Фильтруем задачи
        filtered_tasks = [task for task in data.get("tasks", []) if task["id"] in user_task_ids]
        
        # Фильтруем работы
        filtered_works = user_works
        
        return {
            "users": data["users"],
            "projects": filtered_projects,
            "tasks": filtered_tasks,
            "works": filtered_works,
            "notifications": data["notifications"]
        }
    
    # Для других ролей возвращаем все данные
    return data

# Функции аутентификации
def hash_password(password):
    """Хеширует пароль с солью"""
    salt = os.urandom(32).hex()
    password_hash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    ).hex()
    return f"{salt}${password_hash}"

def verify_password(password, hashed_password):
    """Проверяет пароль против хеша"""
    if not hashed_password or '$' not in hashed_password:
        return False
    
    try:
        salt, stored_hash = hashed_password.split('$')
        new_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        ).hex()
        return new_hash == stored_hash
    except:
        return False

def login(username_input=None, password_input=None):
    """Функция входа в систему"""
    data = load_data()
    
    if username_input is None or password_input is None:
        username = input("Логин: ")
        password = input("Пароль: ")
    else:
        username = username_input
        password = password_input
    
    for user in data["users"]:
        if (user["username"] == username and 
            verify_password(password, user["password"]) and
            user.get("is_active", True)):
            user["role_display"] = ROLES.get(user["role"], user["role"])
            return user
    
    return None

def toggle_user_status(username, current_user):
    """Блокирует/разблокирует учетную запись пользователя"""
    if not current_user.get("permissions", {}).get("manage_users", False):
        return False
    
    if username == current_user["username"]:
        return False
    
    data = load_data()
    
    for user in data["users"]:
        if user["username"] == username:
            user["is_active"] = not user.get("is_active", True)
            save_data(data)
            return True
    
    return False

# Функции файлового менеджера
def ensure_attachments_dir():
    """Создает директорию для вложений если ее нет"""
    if not os.path.exists(ATTACHMENTS_DIR):
        os.makedirs(ATTACHMENTS_DIR)

def save_attachment(file_path, entity_type, entity_id):
    """Сохраняет файл в систему вложений"""
    ensure_attachments_dir()
    
    if not os.path.exists(file_path):
        return None
    
    file_ext = os.path.splitext(file_path)[1]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_hash = hashlib.md5(f"{entity_type}_{entity_id}_{timestamp}".encode()).hexdigest()[:8]
    new_filename = f"{entity_type}_{entity_id}_{file_hash}{file_ext}"
    new_filepath = os.path.join(ATTACHMENTS_DIR, new_filename)
    
    try:
        import shutil
        shutil.copy2(file_path, new_filepath)
        return new_filename
    except Exception as e:
        return None

def get_attachment_path(filename):
    """Возвращает полный путь к файлу вложения"""
    return os.path.join(ATTACHMENTS_DIR, filename) if filename else None

def delete_attachment(filename):
    """Удаляет файл вложения"""
    if filename and os.path.exists(os.path.join(ATTACHMENTS_DIR, filename)):
        try:
            os.remove(os.path.join(ATTACHMENTS_DIR, filename))
            return True
        except Exception:
            return False
    return False

def get_attachment_info(filename):
    """Возвращает информацию о файле вложения"""
    filepath = get_attachment_path(filename)
    if filepath and os.path.exists(filepath):
        try:
            stat = os.stat(filepath)
            return {
                'filename': filename,
                'size': stat.st_size,
                'created': datetime.fromtimestamp(stat.st_ctime)
            }
        except Exception:
            return None
    return None

# Функции отчетов
def generate_gantt_chart(project_id):
    """Генерирует диаграмму Ганта для проекта"""
    try:
        data = load_data()
        project = next((p for p in data["projects"] if p["id"] == project_id), None)
        
        if not project:
            return False, "Проект не найден"
        
        project_tasks = [t for t in data.get("tasks", []) if t.get("project_id") == project_id]
        
        if not project_tasks:
            return False, "В проекте нет задач для построения диаграммы"
        
        # Создаем данные для диаграммы
        tasks_data = []
        for task in project_tasks:
            if task.get('deadline') and task.get('status') not in ['выполнено', 'не_выполнено']:
                try:
                    deadline = datetime.strptime(task['deadline'], '%Y-%m-%d')
                    # Используем дату начала проекта как старт для задачи
                    start_date = datetime.strptime(project['start_date'], '%Y-%m-%d') if project.get('start_date') else datetime.now()
                    
                    tasks_data.append({
                        'task': task['title'],
                        'start': start_date,
                        'end': deadline,
                        'status': task.get('status', 'черновик')
                    })
                except ValueError:
                    continue
        
        if not tasks_data:
            return False, "Нет задач с корректными датами для построения диаграммы"
        
        # Создаем диаграмму
        plt.figure(figsize=(12, 6))
        
        colors = {
            'черновик': 'lightgray',
            'на_рассмотрении': 'lightblue', 
            'в_работе': 'lightgreen',
            'выполнено': 'green',
            'не_выполнено': 'red'
        }
        
        for i, task_data in enumerate(tasks_data):
            color = colors.get(task_data['status'], 'lightgray')
            plt.barh(task_data['task'], 
                    (task_data['end'] - task_data['start']).days,
                    left=task_data['start'],
                    color=color,
                    alpha=0.6,
                    label=task_data['status'] if i == 0 else "")
        
        # Настраиваем внешний вид
        plt.xlabel('Дата')
        plt.ylabel('Задачи')
        plt.title(f'Диаграмма Ганта: {project["name"]}')
        
        # Форматируем даты
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        plt.gca().xaxis.set_major_locator(mdates.WeekdayLocator(interval=1))
        plt.gcf().autofmt_xdate()
        
        # Добавляем легенду
        handles = [plt.Rectangle((0,0),1,1, color=colors[status]) for status in colors]
        plt.legend(handles, colors.keys(), title='Статусы')
        
        # Делаем диаграмму интерактивной
        plt.tight_layout()
        plt.show()
        
        return True, "Диаграмма Ганта отображена"
        
    except Exception as e:
        return False, f"Ошибка при построении диаграммы: {str(e)}"

def generate_comprehensive_report(user):
    """Генерирует комплексный отчет"""
    data = load_data()
    
    report = "КОМПЛЕКСНЫЙ ОТЧЕТ СИСТЕМЫ\n"
    report += "=" * 50 + "\n\n"
    
    # Статистика проектов
    total_projects = len(data["projects"])
    active_projects = len([p for p in data["projects"] if p.get("status") not in ["выполнено", "не_выполнено"]])
    completed_projects = total_projects - active_projects
    
    report += "СТАТИСТИКА ПРОЕКТОВ:\n"
    report += f"Всего проектов: {total_projects}\n"
    report += f"Активных: {active_projects}\n"
    report += f"Завершенных: {completed_projects}\n\n"
    
    # Статистика по статусам проектов
    status_stats = {}
    for project in data["projects"]:
        status = project.get("status", "черновик")
        status_stats[status] = status_stats.get(status, 0) + 1
    
    report += "Распределение по статусам:\n"
    for status, count in status_stats.items():
        report += f"  {status}: {count}\n"
    report += "\n"
    
    # Статистика задач
    total_tasks = len(data.get("tasks", []))
    completed_tasks = len([t for t in data.get("tasks", []) if t.get("status") in ["выполнено", "не_выполнено"]])
    
    report += "СТАТИСТИКА ЗАДАЧ:\n"
    report += f"Всего задач: {total_tasks}\n"
    report += f"Завершенных: {completed_tasks}\n"
    report += f"В работе: {total_tasks - completed_tasks}\n\n"
    
    # Статистика пользователей
    report += "СТАТИСТИКА ПОЛЬЗОВАТЕЛЕЙ:\n"
    report += f"Всего пользователей: {len(data['users'])}\n"
    
    role_stats = {}
    for user_data in data["users"]:
        role = user_data.get("role", "неизвестно")
        role_stats[role] = role_stats.get(role, 0) + 1
    
    for role, count in role_stats.items():
        report += f"  {role}: {count}\n"
    
    return report

def export_report_to_file(report_text, filename):
    """Экспортирует отчет в файл"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(report_text)
        return True, f"Отчет успешно экспортирован в {filename}"
    except Exception as e:
        return False, f"Ошибка при экспорте отчета: {str(e)}"

def check_overdue_tasks():
    """Проверяет просроченные задачи"""
    from datetime import datetime
    
    data = load_data()
    today = datetime.now().date()
    overdue_tasks = []
    
    for task in data.get("tasks", []):
        if task.get("deadline") and task.get("status") not in ["выполнено", "не_выполнено"]:
            try:
                deadline = datetime.strptime(task["deadline"], '%Y-%m-%d').date()
                if deadline < today:
                    overdue_tasks.append(task)
            except ValueError:
                continue
    
    return overdue_tasks

# Функции аудита
def audit_user_actions(action_type, user, entity_type, entity_id, description):
    """Записывает действия пользователя для аудита"""
    try:
        data = load_data()
        
        if "audit_log" not in data:
            data["audit_log"] = []
        
        audit_record = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "username": user["username"],
            "action_type": action_type,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "description": description
        }
        
        data["audit_log"].append(audit_record)
        save_data(data)
    except Exception as e:
        print(f"Ошибка записи аудита: {e}")

# Календарь
class CalendarDialog:
    def __init__(self, parent, current_date=None):
        self.top = tk.Toplevel(parent)
        self.top.title("Выбор даты")
        self.top.geometry("300x300")
        self.top.transient(parent)
        self.top.grab_set()
        
        self.result = None
        self.current_date = current_date or datetime.now()
        
        self.setup_calendar()
        
    def setup_calendar(self):
        header_frame = ttk.Frame(self.top)
        header_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.prev_btn = ttk.Button(header_frame, text="◀", width=3, command=self.prev_month)
        self.prev_btn.pack(side=tk.LEFT)
        
        self.month_label = ttk.Label(header_frame, text="", font=('Arial', 12, 'bold'))
        self.month_label.pack(side=tk.LEFT, expand=True)
        
        self.next_btn = ttk.Button(header_frame, text="▶", width=3, command=self.next_month)
        self.next_btn.pack(side=tk.RIGHT)
        
        days_frame = ttk.Frame(self.top)
        days_frame.pack(fill=tk.X, padx=10, pady=2)
        
        days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
        for day in days:
            label = ttk.Label(days_frame, text=day, width=4, font=('Arial', 9))
            label.pack(side=tk.LEFT)
        
        self.calendar_frame = ttk.Frame(self.top)
        self.calendar_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Button(btn_frame, text="Сегодня", command=self.set_today).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.RIGHT, padx=5)
        ttk.Button(btn_frame, text="OK", command=self.select_date).pack(side=tk.RIGHT, padx=5)
        
        self.update_calendar()
    
    def update_calendar(self):
        month_names = [
            "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
            "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
        ]
        self.month_label.config(text=f"{month_names[self.current_date.month-1]} {self.current_date.year}")
        
        for widget in self.calendar_frame.winfo_children():
            widget.destroy()
        
        cal = calendar.monthcalendar(self.current_date.year, self.current_date.month)
        
        self.day_buttons = []
        for week_num, week in enumerate(cal):
            for day_num, day in enumerate(week):
                if day != 0:
                    btn = ttk.Button(
                        self.calendar_frame, 
                        text=str(day), 
                        width=4,
                        command=lambda d=day: self.set_selected_day(d)
                    )
                    btn.grid(row=week_num, column=day_num, padx=1, pady=1)
                    self.day_buttons.append(btn)
    
    def set_selected_day(self, day):
        self.selected_date = datetime(self.current_date.year, self.current_date.month, day)
        self.select_date()
    
    def set_today(self):
        self.selected_date = datetime.now()
        self.select_date()
    
    def select_date(self):
        if hasattr(self, 'selected_date'):
            self.result = self.selected_date.strftime("%Y-%m-%d")
        self.top.destroy()
    
    def prev_month(self):
        self.current_date = self.current_date.replace(day=1) - timedelta(days=1)
        self.update_calendar()
    
    def next_month(self):
        next_month = self.current_date.month + 1
        next_year = self.current_date.year
        if next_month > 12:
            next_month = 1
            next_year += 1
        self.current_date = self.current_date.replace(year=next_year, month=next_month, day=1)
        self.update_calendar()

def ask_date(parent, current_date=None):
    """Открывает диалог выбора даты"""
    dialog = CalendarDialog(parent, current_date)
    parent.wait_window(dialog.top)
    return dialog.result

# Диалоговые окна
class ProjectDialog:
    def __init__(self, parent, user):
        self.top = tk.Toplevel(parent)
        self.user = user
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Создание проекта")
        self.top.geometry("500x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Название проекта:").pack(pady=5)
        self.name_entry = ttk.Entry(self.top, width=40)
        self.name_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Заказчик:").pack(pady=5)
        self.client_entry = ttk.Entry(self.top, width=40)
        self.client_entry.pack(pady=5)
        
        # Дата начала - исправлено: надпись над полем, поле центрировано
        ttk.Label(self.top, text="Дата начала:").pack(pady=5)
        start_frame = ttk.Frame(self.top)
        start_frame.pack(pady=5)
        self.start_entry = ttk.Entry(start_frame, width=20)
        self.start_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(start_frame, text="📅", width=3, 
                  command=lambda: self.select_date(self.start_entry)).pack(side=tk.LEFT)
        
        # Плановая дата завершения - исправлено: надпись над полем, поле центрировано
        ttk.Label(self.top, text="Плановая дата завершения:").pack(pady=5)
        planned_frame = ttk.Frame(self.top)
        planned_frame.pack(pady=5)
        self.planned_entry = ttk.Entry(planned_frame, width=20)
        self.planned_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(planned_frame, text="📅", width=3,
                  command=lambda: self.select_date(self.planned_entry)).pack(side=tk.LEFT)
        
        ttk.Label(self.top, text="Стоимость:").pack(pady=5)
        self.cost_entry = ttk.Entry(self.top, width=40)
        self.cost_entry.pack(pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="Создать", command=self.create).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def select_date(self, entry_widget):
        selected_date = ask_date(self.top)
        if selected_date:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, selected_date)
    
    def create(self):
        data = load_data()
        project = {
            "id": len(data["projects"]) + 1,
            "name": self.name_entry.get(),
            "client": self.client_entry.get(),
            "start_date": self.start_entry.get(),
            "planned_end": self.planned_entry.get(),
            "actual_end": "",
            "manager": self.user["username"],
            "cost": float(self.cost_entry.get() or 0),
            "status": "черновик",
            "custom_fields": {},
            "attachments": []
        }
        
        data["projects"].append(project)
        save_data(data)
        self.result = True
        self.top.destroy()

class TaskDialog:
    def __init__(self, parent, user, data):
        self.top = tk.Toplevel(parent)
        self.user = user
        self.data = data
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Создание задачи")
        self.top.geometry("500x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Проект:").pack(pady=5)
        self.project_var = tk.StringVar()
        project_combo = ttk.Combobox(self.top, textvariable=self.project_var, width=37)
        projects = [f"{p['id']}: {p['name']}" for p in self.data["projects"]]
        project_combo['values'] = projects
        project_combo.pack(pady=5)
        
        ttk.Label(self.top, text="Название задачи:").pack(pady=5)
        self.title_entry = ttk.Entry(self.top, width=40)
        self.title_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Описание:").pack(pady=5)
        self.desc_entry = tk.Text(self.top, width=38, height=4)
        self.desc_entry.pack(pady=5)
        
        # Приоритет с выпадающим списком
        ttk.Label(self.top, text="Приоритет:").pack(pady=5)
        self.priority_var = tk.StringVar()
        priority_combo = ttk.Combobox(self.top, textvariable=self.priority_var, width=37)
        priority_combo['values'] = PRIORITIES
        priority_combo.pack(pady=5)
        
        # Срок выполнения - исправлено: надпись над полем, поле центрировано
        ttk.Label(self.top, text="Срок выполнения:").pack(pady=5)
        deadline_frame = ttk.Frame(self.top)
        deadline_frame.pack(pady=5)
        self.deadline_entry = ttk.Entry(deadline_frame, width=20)
        self.deadline_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(deadline_frame, text="📅", width=3,
                  command=lambda: self.select_date(self.deadline_entry)).pack(side=tk.LEFT)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="Создать", command=self.create).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def select_date(self, entry_widget):
        selected_date = ask_date(self.top)
        if selected_date:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, selected_date)
    
    def create(self):
        data = load_data()
        
        project_str = self.project_var.get()
        if not project_str:
            messagebox.showerror("Ошибка", "Выберите проект")
            return
        
        project_id = int(project_str.split(":")[0])
        
        task = {
            "id": len(data.get("tasks", [])) + 1,
            "project_id": project_id,
            "title": self.title_entry.get(),
            "description": self.desc_entry.get(1.0, tk.END).strip(),
            "deadline": self.deadline_entry.get(),
            "priority": self.priority_var.get(),
            "responsible": self.user["username"],
            "status": "черновик",
            "custom_fields": {},
            "materials": [],
            "attachments": []
        }
        
        if "tasks" not in data:
            data["tasks"] = []
        data["tasks"].append(task)
        save_data(data)
        self.result = True
        self.top.destroy()

class BreakTaskDialog:
    def __init__(self, parent, task, data, user):
        self.top = tk.Toplevel(parent)
        self.task = task
        self.data = data
        self.user = user
        self.result = None
        self.works = []
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title(f"Разбивка задачи: {self.task.get('title')}")
        self.top.geometry("600x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        # Фрейм для списка созданных работ
        list_frame = ttk.LabelFrame(self.top, text="Созданные работы")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Treeview для отображения созданных работ
        columns = ("Название", "Исполнитель", "Статус")
        self.works_tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=6)
        
        for col in columns:
            self.works_tree.heading(col, text=col)
            self.works_tree.column(col, width=150)
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.works_tree.yview)
        self.works_tree.configure(yscrollcommand=scrollbar.set)
        
        self.works_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Форма для добавления работы
        form_frame = ttk.LabelFrame(self.top, text="Добавление новой работы")
        form_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(form_frame, text="Название работы:").pack(anchor=tk.W, padx=5, pady=2)
        self.work_title = ttk.Entry(form_frame, width=50)
        self.work_title.pack(fill=tk.X, padx=5, pady=2)
        
        ttk.Label(form_frame, text="Описание:").pack(anchor=tk.W, padx=5, pady=2)
        self.work_desc = tk.Text(form_frame, width=50, height=3)
        self.work_desc.pack(fill=tk.X, padx=5, pady=2)
        
        # Убрано поле "Параметры" по требованию
        
        ttk.Label(form_frame, text="Исполнитель:").pack(anchor=tk.W, padx=5, pady=2)
        self.work_executor = ttk.Combobox(form_frame, width=47)
        executors = [u["username"] for u in self.data["users"] if u["role"] in ["исполнитель", "ответственный_исполнитель"]]
        self.work_executor['values'] = executors
        self.work_executor.pack(fill=tk.X, padx=5, pady=2)
        
        btn_frame = ttk.Frame(form_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(btn_frame, text="Добавить работу", command=self.add_work).pack(side=tk.LEFT, padx=5)
        
        # Кнопки сохранения/отмены
        save_frame = ttk.Frame(self.top)
        save_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(save_frame, text="Сохранить все работы", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(save_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def add_work(self):
        title = self.work_title.get()
        if not title:
            messagebox.showwarning("Предупреждение", "Введите название работы")
            return
        
        work = {
            "title": title,
            "description": self.work_desc.get(1.0, tk.END).strip(),
            "parameters": "",  # Параметры убраны
            "executor": self.work_executor.get(),
            "status": "черновик"
        }
        
        self.works.append(work)
        
        # Обновляем Treeview
        self.works_tree.insert("", "end", values=(
            work["title"],
            work["executor"],
            work["status"]
        ))
        
        # Очищаем форму
        self.work_title.delete(0, tk.END)
        self.work_desc.delete(1.0, tk.END)
        self.work_executor.set("")
    
    def save(self):
        if not self.works:
            messagebox.showwarning("Предупреждение", "Нет работ для сохранения")
            return
        
        data = load_data()
        
        for work_data in self.works:
            work = {
                "id": len(data.get("works", [])) + 1,
                "task_id": self.task["id"],
                "title": work_data["title"],
                "description": work_data["description"],
                "parameters": work_data["parameters"],
                "executor": work_data["executor"],
                "status": work_data["status"],
                "created_by": self.user["username"],
                "attachments": []
            }
            
            if "works" not in data:
                data["works"] = []
            data["works"].append(work)
        
        save_data(data)
        self.result = True
        self.top.destroy()

class ProjectDetailsDialog:
    def __init__(self, parent, project, data):
        self.top = tk.Toplevel(parent)
        self.project = project
        self.data = data
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title(f"Проект: {self.project.get('name', '')}")
        self.top.geometry("600x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        notebook = ttk.Notebook(self.top)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.setup_basic_info_tab(notebook)
        self.setup_tasks_tab(notebook)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Закрыть", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def setup_basic_info_tab(self, notebook):
        basic_frame = ttk.Frame(notebook)
        notebook.add(basic_frame, text="Основная информация")
        
        info_frame = ttk.Frame(basic_frame)
        info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        fields = [
            ("ID:", self.project.get('id', '')),
            ("Название:", self.project.get('name', '')),
            ("Статус:", self.project.get('status', 'черновик')),
            ("Заказчик:", self.project.get('client', '')),
            ("Руководитель:", self.project.get('manager', '')),
            ("Дата начала:", self.project.get('start_date', '')),
            ("Плановая дата завершения:", self.project.get('planned_end', '')),
            ("Фактическая дата завершения:", self.project.get('actual_end', 'Не завершен')),
            ("Стоимость:", f"{self.project.get('cost', 0):.2f}")
        ]
        
        for i, (label, value) in enumerate(fields):
            ttk.Label(info_frame, text=label, font=('Arial', 10, 'bold')).grid(row=i, column=0, sticky=tk.W, pady=2)
            ttk.Label(info_frame, text=value).grid(row=i, column=1, sticky=tk.W, pady=2, padx=10)
    
    def setup_tasks_tab(self, notebook):
        tasks_frame = ttk.Frame(notebook)
        notebook.add(tasks_frame, text="Задачи проекта")
        
        table_frame = ttk.Frame(tasks_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        columns = ("ID", "Название", "Статус", "Ответственный", "Срок", "Приоритет")
        tasks_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=10)
        
        for col in columns:
            tasks_tree.heading(col, text=col)
            tasks_tree.column(col, width=100)
        
        tasks_tree.column("Название", width=150)
        
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tasks_tree.yview)
        tasks_tree.configure(yscrollcommand=scrollbar.set)
        
        tasks_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        project_tasks = [t for t in self.data.get("tasks", []) if t.get("project_id") == self.project.get("id")]
        for task in project_tasks:
            tasks_tree.insert("", "end", values=(
                task.get("id", ""),
                task.get("title", ""),
                task.get("status", "черновик"),
                task.get("responsible", ""),
                task.get("deadline", ""),
                task.get("priority", "")
            ))
class TaskDetailsDialog:
    def __init__(self, parent, task, data):
        self.top = tk.Toplevel(parent)
        self.task = task
        self.data = data
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title(f"Задача: {self.task.get('title', '')}")
        self.top.geometry("600x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        # Создаем Notebook для вкладок
        notebook = ttk.Notebook(self.top)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.setup_basic_info_tab(notebook)
        self.setup_works_tab(notebook)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Закрыть", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def setup_basic_info_tab(self, notebook):
        basic_frame = ttk.Frame(notebook)
        notebook.add(basic_frame, text="Основная информация")
        
        info_frame = ttk.Frame(basic_frame)
        info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Находим проект
        project = next((p for p in self.data["projects"] if p["id"] == self.task.get("project_id")), None)
        project_name = project.get("name", "Неизвестно") if project else "Неизвестно"
        
        fields = [
            ("ID:", self.task.get('id', '')),
            ("Название:", self.task.get('title', '')),
            ("Статус:", self.task.get('status', 'черновик')),
            ("Проект:", project_name),
            ("Описание:", self.task.get('description', '')),
            ("Ответственный:", self.task.get('responsible', '')),
            ("Срок:", self.task.get('deadline', '')),
            ("Приоритет:", self.task.get('priority', ''))
        ]
        
        for i, (label, value) in enumerate(fields):
            ttk.Label(info_frame, text=label, font=('Arial', 10, 'bold')).grid(row=i, column=0, sticky=tk.W, pady=2)
            if label == "Описание:":
                # Для описания используем Text виджет с прокруткой
                desc_frame = ttk.Frame(info_frame)
                desc_frame.grid(row=i, column=1, sticky=tk.W, pady=2, padx=10)
                
                scrollbar = ttk.Scrollbar(desc_frame, orient=tk.VERTICAL)
                text_widget = tk.Text(desc_frame, wrap=tk.WORD, width=40, height=4, 
                                    yscrollcommand=scrollbar.set)
                text_widget.insert(1.0, value)
                text_widget.config(state=tk.DISABLED)
                
                text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                scrollbar.config(command=text_widget.yview)
            else:
                ttk.Label(info_frame, text=value, wraplength=300).grid(row=i, column=1, sticky=tk.W, pady=2, padx=10)
    
    def setup_works_tab(self, notebook):
        works_frame = ttk.Frame(notebook)
        notebook.add(works_frame, text="Работы задачи")
        
        table_frame = ttk.Frame(works_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        columns = ("ID", "Название", "Статус", "Исполнитель", "Создатель")
        works_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=10)
        
        for col in columns:
            works_tree.heading(col, text=col)
            works_tree.column(col, width=100)
        
        works_tree.column("Название", width=150)
        
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=works_tree.yview)
        works_tree.configure(yscrollcommand=scrollbar.set)
        
        works_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        task_works = [w for w in self.data.get("works", []) if w.get("task_id") == self.task.get("id")]
        for work in task_works:
            works_tree.insert("", "end", values=(
                work.get("id", ""),
                work.get("title", ""),
                work.get("status", "черновик"),
                work.get("executor", ""),
                work.get("created_by", "")
            ))

class WorkDetailsDialog:
    def __init__(self, parent, work, data):
        self.top = tk.Toplevel(parent)
        self.work = work
        self.data = data
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title(f"Работа: {self.work.get('title', '')}")
        self.top.geometry("500x400")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        info_frame = ttk.Frame(self.top)
        info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Находим задачу
        task = next((t for t in self.data.get("tasks", []) if t["id"] == self.work.get("task_id")), None)
        task_title = task.get("title", "Неизвестно") if task else "Неизвестно"
        
        fields = [
            ("ID:", self.work.get('id', '')),
            ("Название:", self.work.get('title', '')),
            ("Статус:", self.work.get('status', 'черновик')),
            ("Задача:", task_title),
            ("Описание:", self.work.get('description', '')),
            ("Исполнитель:", self.work.get('executor', '')),
            ("Создатель:", self.work.get('created_by', ''))
        ]
        
        for i, (label, value) in enumerate(fields):
            ttk.Label(info_frame, text=label, font=('Arial', 10, 'bold')).grid(row=i, column=0, sticky=tk.W, pady=3)
            if label == "Описание:":
                # Для описания используем Text виджет с прокруткой
                desc_frame = ttk.Frame(info_frame)
                desc_frame.grid(row=i, column=1, sticky=tk.W, pady=3, padx=10)
                
                scrollbar = ttk.Scrollbar(desc_frame, orient=tk.VERTICAL)
                text_widget = tk.Text(desc_frame, wrap=tk.WORD, width=40, height=3, 
                                    yscrollcommand=scrollbar.set)
                text_widget.insert(1.0, value)
                text_widget.config(state=tk.DISABLED)
                
                text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                scrollbar.config(command=text_widget.yview)
            else:
                ttk.Label(info_frame, text=value, wraplength=250).grid(row=i, column=1, sticky=tk.W, pady=3, padx=10)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Закрыть", command=self.top.destroy).pack(side=tk.LEFT, padx=5)

class EditProjectDialog:
    def __init__(self, parent, project):
        self.top = tk.Toplevel(parent)
        self.project = project
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Редактирование проекта")
        self.top.geometry("500x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Название проекта:").pack(pady=5)
        self.name_entry = ttk.Entry(self.top, width=40)
        self.name_entry.insert(0, self.project.get("name", ""))
        self.name_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Заказчик:").pack(pady=5)
        self.client_entry = ttk.Entry(self.top, width=40)
        self.client_entry.insert(0, self.project.get("client", ""))
        self.client_entry.pack(pady=5)
        
        # Дата начала с календарем - исправлено
        ttk.Label(self.top, text="Дата начала:").pack(pady=5)
        start_frame = ttk.Frame(self.top)
        start_frame.pack(pady=5)
        self.start_entry = ttk.Entry(start_frame, width=20)
        self.start_entry.insert(0, self.project.get("start_date", ""))
        self.start_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(start_frame, text="📅", width=3, 
                  command=lambda: self.select_date(self.start_entry)).pack(side=tk.LEFT)
        
        # Плановая дата завершения с календарем - исправлено
        ttk.Label(self.top, text="Плановая дата завершения:").pack(pady=5)
        planned_frame = ttk.Frame(self.top)
        planned_frame.pack(pady=5)
        self.planned_entry = ttk.Entry(planned_frame, width=20)
        self.planned_entry.insert(0, self.project.get("planned_end", ""))
        self.planned_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(planned_frame, text="📅", width=3,
                  command=lambda: self.select_date(self.planned_entry)).pack(side=tk.LEFT)
        
        ttk.Label(self.top, text="Стоимость:").pack(pady=5)
        self.cost_entry = ttk.Entry(self.top, width=40)
        self.cost_entry.insert(0, str(self.project.get("cost", 0)))
        self.cost_entry.pack(pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def select_date(self, entry_widget):
        """Открывает календарь для выбора даты"""
        selected_date = ask_date(self.top)
        if selected_date:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, selected_date)
    
    def save(self):
        self.project["name"] = self.name_entry.get()
        self.project["client"] = self.client_entry.get()
        self.project["start_date"] = self.start_entry.get()
        self.project["planned_end"] = self.planned_entry.get()
        self.project["cost"] = float(self.cost_entry.get() or 0)
        
        self.result = True
        self.top.destroy()

class EditTaskDialog:
    def __init__(self, parent, task, data):
        self.top = tk.Toplevel(parent)
        self.task = task
        self.data = data
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Редактирование задачи")
        self.top.geometry("500x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Название задачи:").pack(pady=5)
        self.title_entry = ttk.Entry(self.top, width=40)
        self.title_entry.insert(0, self.task.get("title", ""))
        self.title_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Описание:").pack(pady=5)
        self.desc_entry = tk.Text(self.top, width=38, height=4)
        self.desc_entry.insert(1.0, self.task.get("description", ""))
        self.desc_entry.pack(pady=5)
        
        # Срок выполнения с календарем - исправлено
        ttk.Label(self.top, text="Срок выполнения:").pack(pady=5)
        deadline_frame = ttk.Frame(self.top)
        deadline_frame.pack(pady=5)
        self.deadline_entry = ttk.Entry(deadline_frame, width=20)
        self.deadline_entry.insert(0, self.task.get("deadline", ""))
        self.deadline_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(deadline_frame, text="📅", width=3,
                  command=lambda: self.select_date(self.deadline_entry)).pack(side=tk.LEFT)
        
        ttk.Label(self.top, text="Приоритет:").pack(pady=5)
        self.priority_entry = ttk.Entry(self.top, width=40)
        self.priority_entry.insert(0, self.task.get("priority", ""))
        self.priority_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Ответственный:").pack(pady=5)
        self.responsible_var = tk.StringVar()
        responsible_combo = ttk.Combobox(self.top, textvariable=self.responsible_var, width=37)
        users = [u["username"] for u in self.data["users"]]
        responsible_combo['values'] = users
        responsible_combo.set(self.task.get("responsible", ""))
        responsible_combo.pack(pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def select_date(self, entry_widget):
        """Открывает календарь для выбора даты"""
        selected_date = ask_date(self.top)
        if selected_date:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, selected_date)
    
    def save(self):
        self.task["title"] = self.title_entry.get()
        self.task["description"] = self.desc_entry.get(1.0, tk.END).strip()
        self.task["deadline"] = self.deadline_entry.get()
        self.task["priority"] = self.priority_entry.get()
        self.task["responsible"] = self.responsible_var.get()
        
        self.result = True
        self.top.destroy()

class EditWorkDialog:
    def __init__(self, parent, work, data):
        self.top = tk.Toplevel(parent)
        self.work = work
        self.data = data
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Редактирование работы")
        self.top.geometry("400x400")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Название работы:").pack(pady=5)
        self.title_entry = ttk.Entry(self.top, width=40)
        self.title_entry.insert(0, self.work.get("title", ""))
        self.title_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Описание:").pack(pady=5)
        self.desc_entry = tk.Text(self.top, width=38, height=4)
        self.desc_entry.insert(1.0, self.work.get("description", ""))
        self.desc_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Исполнитель:").pack(pady=5)
        self.executor_var = tk.StringVar()
        executor_combo = ttk.Combobox(self.top, textvariable=self.executor_var, width=37)
        executors = [u["username"] for u in self.data["users"] if u["role"] in ["исполнитель", "ответственный_исполнитель"]]
        executor_combo['values'] = executors
        executor_combo.set(self.work.get("executor", ""))
        executor_combo.pack(pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def save(self):
        self.work["title"] = self.title_entry.get()
        self.work["description"] = self.desc_entry.get(1.0, tk.END).strip()
        self.work["executor"] = self.executor_var.get()
        
        self.result = True
        self.top.destroy()

class ChangeStatusDialog:
    def __init__(self, parent, entity_type, statuses, current_status):
        self.top = tk.Toplevel(parent)
        self.entity_type = entity_type
        self.statuses = statuses
        self.current_status = current_status
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title(f"Изменение статуса {self.entity_type}")
        self.top.geometry("300x200")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text=f"Текущий статус: {self.current_status}").pack(pady=10)
        ttk.Label(self.top, text="Новый статус:").pack(pady=5)
        
        self.status_var = tk.StringVar(value=self.current_status)
        status_combo = ttk.Combobox(self.top, textvariable=self.status_var, width=20)
        status_combo['values'] = self.statuses
        status_combo.pack(pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="Изменить", command=self.change).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def change(self):
        self.result = self.status_var.get()
        self.top.destroy()

class UserDialog:
    def __init__(self, parent, user):
        self.top = tk.Toplevel(parent)
        self.user = user
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Создание пользователя")
        self.top.geometry("300x300")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Логин:").pack(pady=5)
        self.username_entry = ttk.Entry(self.top, width=30)
        self.username_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Пароль:").pack(pady=5)
        self.password_entry = ttk.Entry(self.top, width=30, show="*")
        self.password_entry.pack(pady=5)
        
        ttk.Label(self.top, text="ФИО:").pack(pady=5)
        self.fullname_entry = ttk.Entry(self.top, width=30)
        self.fullname_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Роль:").pack(pady=5)
        self.role_var = tk.StringVar()
        role_combo = ttk.Combobox(self.top, textvariable=self.role_var, width=27)
        role_combo['values'] = ("администратор", "руководитель_проекта", "ответственный_исполнитель", "исполнитель")
        role_combo.pack(pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="Создать", command=self.create).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def create(self):
        data = load_data()
        
        username = self.username_entry.get()
        if any(user["username"] == username for user in data["users"]):
            messagebox.showerror("Ошибка", "Пользователь с таким логином уже существует")
            return
        
        user = {
            "username": username,
            "password": hash_password(self.password_entry.get()),
            "role": self.role_var.get(),
            "full_name": self.fullname_entry.get(),
            "permissions": get_default_permissions(self.role_var.get())
        }
        
        data["users"].append(user)
        save_data(data)
        self.result = True
        self.top.destroy()

class EditUserDialog:
    def __init__(self, parent, user):
        self.top = tk.Toplevel(parent)
        self.user = user
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Редактирование пользователя")
        self.top.geometry("300x300")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Логин:").pack(pady=5)
        ttk.Label(self.top, text=self.user["username"]).pack(pady=5)
        
        ttk.Label(self.top, text="Пароль:").pack(pady=5)
        self.password_entry = ttk.Entry(self.top, width=30, show="*")
        self.password_entry.pack(pady=5)
        
        ttk.Label(self.top, text="ФИО:").pack(pady=5)
        self.fullname_entry = ttk.Entry(self.top, width=30)
        self.fullname_entry.insert(0, self.user.get("full_name", ""))
        self.fullname_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Роль:").pack(pady=5)
        self.role_var = tk.StringVar(value=self.user.get("role", ""))
        role_combo = ttk.Combobox(self.top, textvariable=self.role_var, width=27)
        role_combo['values'] = ("администратор", "руководитель_проекта", "ответственный_исполнитель", "исполнитель")
        role_combo.pack(pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=20)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def save(self):
        if self.password_entry.get():
            self.user["password"] = hash_password(self.password_entry.get())
        
        self.user["full_name"] = self.fullname_entry.get()
        self.user["role"] = self.role_var.get()
        
        self.result = True
        self.top.destroy()

class ManagePermissionsDialog:
    def __init__(self, parent, user):
        self.top = tk.Toplevel(parent)
        self.user = user
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title(f"Права доступа: {self.user['username']}")
        self.top.geometry("400x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text=f"Настройка прав для {self.user['username']}").pack(pady=10)
        
        self.permission_vars = {}
        
        # Фрейм для прав с прокруткой
        frame = ttk.Frame(self.top)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        canvas = tk.Canvas(frame)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        for perm_key, perm_name in AVAILABLE_PERMISSIONS.items():
            var = tk.BooleanVar(value=self.user.get("permissions", {}).get(perm_key, False))
            self.permission_vars[perm_key] = var
            
            cb = ttk.Checkbutton(self.scrollable_frame, text=perm_name, variable=var)
            cb.pack(anchor=tk.W, pady=2)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def save(self):
        for perm_key, var in self.permission_vars.items():
            self.user["permissions"][perm_key] = var.get()
        
        self.result = True
        self.top.destroy()

# РАСШИРЕННЫЕ ДИАЛОГОВЫЕ ОКНА

class EnhancedProjectDialog:
    def __init__(self, parent, project, user):
        self.top = tk.Toplevel(parent)
        self.project = project
        self.user = user
        self.result = None
        self.attachments = project.get("attachments", [])
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Редактирование проекта")
        self.top.geometry("500x600")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        # Создаем Notebook для вкладок
        self.notebook = ttk.Notebook(self.top)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Основная информация (убрана вкладка "Дополнительные поля")
        self.setup_basic_info_tab()
        # Вложения
        self.setup_attachments_tab()
        
        # Кнопки
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def setup_basic_info_tab(self):
        basic_frame = ttk.Frame(self.notebook)
        self.notebook.add(basic_frame, text="Основная информация")
        
        ttk.Label(basic_frame, text="Название проекта:").pack(pady=5)
        self.name_entry = ttk.Entry(basic_frame, width=50)
        self.name_entry.insert(0, self.project.get("name", ""))
        self.name_entry.pack(pady=5)
        
        ttk.Label(basic_frame, text="Заказчик:").pack(pady=5)
        self.client_entry = ttk.Entry(basic_frame, width=50)
        self.client_entry.insert(0, self.project.get("client", ""))
        self.client_entry.pack(pady=5)
        
        # Дата начала с календарем - исправлено
        ttk.Label(basic_frame, text="Дата начала:").pack(pady=5)
        start_frame = ttk.Frame(basic_frame)
        start_frame.pack(pady=5)
        self.start_entry = ttk.Entry(start_frame, width=20)
        self.start_entry.insert(0, self.project.get("start_date", ""))
        self.start_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(start_frame, text="📅", width=3, 
                  command=lambda: self.select_date(self.start_entry)).pack(side=tk.LEFT)
        
        # Плановая дата завершения с календарем - исправлено
        ttk.Label(basic_frame, text="Плановая дата завершения:").pack(pady=5)
        planned_frame = ttk.Frame(basic_frame)
        planned_frame.pack(pady=5)
        self.planned_entry = ttk.Entry(planned_frame, width=20)
        self.planned_entry.insert(0, self.project.get("planned_end", ""))
        self.planned_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(planned_frame, text="📅", width=3,
                  command=lambda: self.select_date(self.planned_entry)).pack(side=tk.LEFT)
        
        ttk.Label(basic_frame, text="Стоимость:").pack(pady=5)
        self.cost_entry = ttk.Entry(basic_frame, width=50)
        self.cost_entry.insert(0, str(self.project.get("cost", 0)))
        self.cost_entry.pack(pady=5)
    
    def setup_attachments_tab(self):
        attach_frame = ttk.Frame(self.notebook)
        self.notebook.add(attach_frame, text="Вложения")
        
        # Список вложений
        self.attach_listbox = tk.Listbox(attach_frame, height=10)
        scrollbar = ttk.Scrollbar(attach_frame, orient=tk.VERTICAL, command=self.attach_listbox.yview)
        self.attach_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.attach_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Кнопки управления вложениями
        btn_frame = ttk.Frame(attach_frame)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(btn_frame, text="Добавить файл", command=self.add_attachment).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Удалить файл", command=self.remove_attachment).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Открыть файл", command=self.open_attachment).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Информация", command=self.attachment_info).pack(side=tk.LEFT, padx=2)
        
        self.load_attachments()
    
    def load_attachments(self):
        """Загружает список вложений"""
        self.attach_listbox.delete(0, tk.END)
        for attachment in self.attachments:
            self.attach_listbox.insert(tk.END, attachment)
    
    def select_date(self, entry_widget):
        """Открывает календарь для выбора даты"""
        selected_date = ask_date(self.top)
        if selected_date:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, selected_date)
    
    def add_attachment(self):
        """Добавляет вложение к проекту"""
        if not self.user.get("permissions", {}).get("manage_attachments", False):
            messagebox.showerror("Ошибка", "У вас нет прав для управления вложениями")
            return
        
        file_path = filedialog.askopenfilename(
            title="Выберите файл для прикрепления",
            filetypes=[("Все файлы", "*.*"), ("Документы", "*.pdf *.doc *.docx *.txt"),
                      ("Изображения", "*.jpg *.jpeg *.png *.gif"), ("Архивы", "*.zip *.rar")]
        )
        
        if file_path:
            filename = save_attachment(file_path, "project", self.project["id"])
            if filename:
                self.attachments.append(filename)
                self.load_attachments()
                messagebox.showinfo("Успех", "Файл успешно прикреплен")
                
                # Аудит действий
                audit_user_actions("ADD_ATTACHMENT", self.user, "PROJECT", 
                                 self.project["id"], f"Файл: {os.path.basename(file_path)}")
            else:
                messagebox.showerror("Ошибка", "Не удалось прикрепить файл")
    
    def remove_attachment(self):
        """Удаляет выбранное вложение"""
        selection = self.attach_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите файл для удаления")
            return
        
        filename = self.attachments[selection[0]]
        if delete_attachment(filename):
            self.attachments.remove(filename)
            self.load_attachments()
            messagebox.showinfo("Успех", "Файл удален")
            
            # Аудит действий
            audit_user_actions("REMOVE_ATTACHMENT", self.user, "PROJECT", 
                             self.project["id"], f"Файл: {filename}")
    
    def open_attachment(self):
        """Открывает выбранное вложение"""
        selection = self.attach_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите файл для открытия")
            return
        
        filename = self.attachments[selection[0]]
        filepath = get_attachment_path(filename)
        
        if filepath and os.path.exists(filepath):
            try:
                os.startfile(filepath)  # Windows
                # Для Linux: os.system(f'xdg-open "{filepath}"')
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось открыть файл: {e}")
        else:
            messagebox.showerror("Ошибка", "Файл не найден")
    
    def attachment_info(self):
        """Показывает информацию о вложении"""
        selection = self.attach_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите файл для просмотра информации")
            return
        
        filename = self.attachments[selection[0]]
        info = get_attachment_info(filename)
        
        if info:
            message = f"Информация о файле:\n\n"
            message += f"Имя файла: {info['filename']}\n"
            message += f"Размер: {info['size']} байт\n"
            message += f"Создан: {info['created'].strftime('%Y-%m-%d %H:%M:%S')}\n"
            messagebox.showinfo("Информация о файле", message)
        else:
            messagebox.showerror("Ошибка", "Не удалось получить информацию о файле")
    
    def save(self):
        """Сохраняет изменения проекта"""
        self.project["name"] = self.name_entry.get()
        self.project["client"] = self.client_entry.get()
        self.project["start_date"] = self.start_entry.get()
        self.project["planned_end"] = self.planned_entry.get()
        self.project["cost"] = float(self.cost_entry.get() or 0)
        self.project["attachments"] = self.attachments
        
        save_data(load_data())
        self.result = True
        
        # Аудит действий
        audit_user_actions("EDIT_PROJECT", self.user, "PROJECT", self.project["id"], 
                         f"Название: {self.project['name']}")
        
        self.top.destroy()

class EnhancedTaskDialog:
    def __init__(self, parent, task, data, user):
        self.top = tk.Toplevel(parent)
        self.task = task
        self.data = data
        self.user = user
        self.result = None
        self.attachments = task.get("attachments", [])
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Редактирование задачи")
        self.top.geometry("500x600")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        # Создаем Notebook для вкладок
        self.notebook = ttk.Notebook(self.top)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Основная информация
        self.setup_basic_info_tab()
        # Вложения
        self.setup_attachments_tab()
        
        # Кнопки
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def setup_basic_info_tab(self):
        basic_frame = ttk.Frame(self.notebook)
        self.notebook.add(basic_frame, text="Основная информация")
        
        ttk.Label(basic_frame, text="Название задачи:").pack(pady=5)
        self.title_entry = ttk.Entry(basic_frame, width=50)
        self.title_entry.insert(0, self.task.get("title", ""))
        self.title_entry.pack(pady=5)
        
        ttk.Label(basic_frame, text="Описание:").pack(pady=5)
        self.desc_entry = tk.Text(basic_frame, width=50, height=4)
        self.desc_entry.insert(1.0, self.task.get("description", ""))
        self.desc_entry.pack(pady=5)
        
        # Срок выполнения с календарем - исправлено
        ttk.Label(basic_frame, text="Срок выполнения:").pack(pady=5)
        deadline_frame = ttk.Frame(basic_frame)
        deadline_frame.pack(pady=5)
        self.deadline_entry = ttk.Entry(deadline_frame, width=20)
        self.deadline_entry.insert(0, self.task.get("deadline", ""))
        self.deadline_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(deadline_frame, text="📅", width=3,
                  command=lambda: self.select_date(self.deadline_entry)).pack(side=tk.LEFT)
        
        ttk.Label(basic_frame, text="Приоритет:").pack(pady=5)
        self.priority_entry = ttk.Entry(basic_frame, width=50)
        self.priority_entry.insert(0, self.task.get("priority", ""))
        self.priority_entry.pack(pady=5)
        
        ttk.Label(basic_frame, text="Ответственный:").pack(pady=5)
        self.responsible_var = tk.StringVar()
        responsible_combo = ttk.Combobox(basic_frame, textvariable=self.responsible_var, width=47)
        users = [u["username"] for u in self.data["users"]]
        responsible_combo['values'] = users
        responsible_combo.set(self.task.get("responsible", ""))
        responsible_combo.pack(pady=5)
    
    def setup_attachments_tab(self):
        attach_frame = ttk.Frame(self.notebook)
        self.notebook.add(attach_frame, text="Вложения")
        
        # Список вложений
        self.attach_listbox = tk.Listbox(attach_frame, height=10)
        scrollbar = ttk.Scrollbar(attach_frame, orient=tk.VERTICAL, command=self.attach_listbox.yview)
        self.attach_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.attach_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Кнопки управления вложениями
        btn_frame = ttk.Frame(attach_frame)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(btn_frame, text="Добавить файл", command=self.add_attachment).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Удалить файл", command=self.remove_attachment).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="Открыть файл", command=self.open_attachment).pack(side=tk.LEFT, padx=2)
        
        self.load_attachments()
    
    def load_attachments(self):
        """Загружает список вложений"""
        self.attach_listbox.delete(0, tk.END)
        for attachment in self.attachments:
            self.attach_listbox.insert(tk.END, attachment)
    
    def select_date(self, entry_widget):
        """Открывает календарь для выбора даты"""
        selected_date = ask_date(self.top)
        if selected_date:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, selected_date)
    
    def add_attachment(self):
        """Добавляет вложение к задаче"""
        if not self.user.get("permissions", {}).get("manage_attachments", False):
            messagebox.showerror("Ошибка", "У вас нет прав для управления вложениями")
            return
        
        file_path = filedialog.askopenfilename(
            title="Выберите файл для прикрепления",
            filetypes=[("Все файлы", "*.*"), ("Документы", "*.pdf *.doc *.docx *.txt"),
                      ("Изображения", "*.jpg *.jpeg *.png *.gif")]
        )
        
        if file_path:
            filename = save_attachment(file_path, "task", self.task["id"])
            if filename:
                self.attachments.append(filename)
                self.load_attachments()
                messagebox.showinfo("Успех", "Файл успешно прикреплен")
                
                # Аудит действий
                audit_user_actions("ADD_ATTACHMENT", self.user, "TASK", 
                                 self.task["id"], f"Файл: {os.path.basename(file_path)}")
            else:
                messagebox.showerror("Ошибка", "Не удалось прикрепить файл")
    
    def remove_attachment(self):
        """Удаляет выбранное вложение"""
        selection = self.attach_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите файл для удаления")
            return
        
        filename = self.attachments[selection[0]]
        if delete_attachment(filename):
            self.attachments.remove(filename)
            self.load_attachments()
            messagebox.showinfo("Успех", "Файл удален")
            
            # Аудит действий
            audit_user_actions("REMOVE_ATTACHMENT", self.user, "TASK", 
                             self.task["id"], f"Файл: {filename}")
    
    def open_attachment(self):
        """Открывает выбранное вложение"""
        selection = self.attach_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите файл для открытия")
            return
        
        filename = self.attachments[selection[0]]
        filepath = get_attachment_path(filename)
        
        if filepath and os.path.exists(filepath):
            try:
                os.startfile(filepath)  # Windows
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось открыть файл: {e}")
        else:
            messagebox.showerror("Ошибка", "Файл не найден")
    
    def save(self):
        """Сохраняет изменения задачи"""
        self.task["title"] = self.title_entry.get()
        self.task["description"] = self.desc_entry.get(1.0, tk.END).strip()
        self.task["deadline"] = self.deadline_entry.get()
        self.task["priority"] = self.priority_entry.get()
        self.task["responsible"] = self.responsible_var.get()
        self.task["attachments"] = self.attachments
        
        save_data(self.data)
        self.result = True
        
        # Аудит действий
        audit_user_actions("EDIT_TASK", self.user, "TASK", self.task["id"], 
                         f"Название: {self.task['title']}")
        
        self.top.destroy()

class EnhancedWorkDialog:
    def __init__(self, parent, work, data, user):
        self.top = tk.Toplevel(parent)
        self.work = work
        self.data = data
        self.user = user
        self.result = None
        self.attachments = work.get("attachments", [])
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Редактирование работы")
        self.top.geometry("500x500")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Название работы:").pack(pady=5)
        self.title_entry = ttk.Entry(self.top, width=50)
        self.title_entry.insert(0, self.work.get("title", ""))
        self.title_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Описание:").pack(pady=5)
        self.desc_entry = tk.Text(self.top, width=50, height=4)
        self.desc_entry.insert(1.0, self.work.get("description", ""))
        self.desc_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Исполнитель:").pack(pady=5)
        self.executor_var = tk.StringVar()
        executor_combo = ttk.Combobox(self.top, textvariable=self.executor_var, width=47)
        executors = [u["username"] for u in self.data["users"] if u["role"] in ["исполнитель", "ответственный_исполнитель"]]
        executor_combo['values'] = executors
        executor_combo.set(self.work.get("executor", ""))
        executor_combo.pack(pady=5)
        
        # Кнопки вложений
        attach_frame = ttk.Frame(self.top)
        attach_frame.pack(pady=10)
        
        ttk.Button(attach_frame, text="Добавить файл", command=self.add_attachment).pack(side=tk.LEFT, padx=2)
        ttk.Button(attach_frame, text="Удалить файл", command=self.remove_attachment).pack(side=tk.LEFT, padx=2)
        
        # Список вложений
        self.attach_listbox = tk.Listbox(self.top, height=5)
        self.attach_listbox.pack(pady=5, padx=10, fill=tk.BOTH, expand=True)
        self.load_attachments()
        
        # Кнопки сохранения
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def load_attachments(self):
        """Загружает список вложений"""
        self.attach_listbox.delete(0, tk.END)
        for attachment in self.attachments:
            self.attach_listbox.insert(tk.END, attachment)
    
    def add_attachment(self):
        """Добавляет вложение к работе"""
        if not self.user.get("permissions", {}).get("manage_attachments", False):
            messagebox.showerror("Ошибка", "У вас нет прав для управления вложениями")
            return
        
        file_path = filedialog.askopenfilename(
            title="Выберите файл для прикрепления",
            filetypes=[("Все файлы", "*.*"), ("Документы", "*.pdf *.doc *.docx *.txt"),
                      ("Изображения", "*.jpg *.jpeg *.png *.gif")]
        )
        
        if file_path:
            filename = save_attachment(file_path, "work", self.work["id"])
            if filename:
                self.attachments.append(filename)
                self.load_attachments()
                messagebox.showinfo("Успех", "Файл успешно прикреплен")
            else:
                messagebox.showerror("Ошибка", "Не удалось прикрепить файл")
    
    def remove_attachment(self):
        """Удаляет выбранное вложение"""
        selection = self.attach_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите файл для удаления")
            return
        
        filename = self.attachments[selection[0]]
        if delete_attachment(filename):
            self.attachments.remove(filename)
            self.load_attachments()
            messagebox.showinfo("Успех", "Файл удален")
    
    def save(self):
        """Сохраняет изменения работы"""
        self.work["title"] = self.title_entry.get()
        self.work["description"] = self.desc_entry.get(1.0, tk.END).strip()
        self.work["executor"] = self.executor_var.get()
        self.work["attachments"] = self.attachments
        
        save_data(self.data)
        self.result = True
        self.top.destroy()

class AdvancedReportsDialog:
    def __init__(self, parent, user, data):
        self.top = tk.Toplevel(parent)
        self.user = user
        self.data = data
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Расширенная отчетность")
        self.top.geometry("500x400")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Расширенные отчеты", 
                 font=('Arial', 14, 'bold')).pack(pady=20)
        
        # Кнопки отчетов
        reports_frame = ttk.Frame(self.top)
        reports_frame.pack(pady=20, padx=20, fill=tk.BOTH, expand=True)
        
        ttk.Button(reports_frame, text="📊 Комплексный отчет", 
                  command=self.generate_comprehensive_report, width=25).pack(pady=10)
        ttk.Button(reports_frame, text="📅 Диаграмма Ганта", 
                  command=self.show_gantt_dialog, width=25).pack(pady=10)
        ttk.Button(reports_frame, text="⚠️  Просроченные задачи", 
                  command=self.show_overdue_tasks, width=25).pack(pady=10)
        ttk.Button(reports_frame, text="📈 Статистика проектов", 
                  command=self.show_project_stats, width=25).pack(pady=10)
        
        # Область для вывода отчетов
        self.report_text = tk.Text(self.top, height=15, width=60)
        self.report_text.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
        
        # Кнопки экспорта
        export_frame = ttk.Frame(self.top)
        export_frame.pack(pady=10)
        
        ttk.Button(export_frame, text="Экспорт отчета", 
                  command=self.export_report).pack(side=tk.LEFT, padx=5)
        ttk.Button(export_frame, text="Очистить", 
                  command=self.clear_report).pack(side=tk.LEFT, padx=5)
    
    def generate_comprehensive_report(self):
        """Генерирует комплексный отчет"""
        report = generate_comprehensive_report(self.user)
        self.display_report(report)
    
    def show_gantt_dialog(self):
        """Показывает диалог для выбора проекта для диаграммы Ганта"""
        dialog = GanttProjectDialog(self.top, self.data)
        self.top.wait_window(dialog.top)
        if dialog.result:
            success, message = generate_gantt_chart(dialog.result)
            if success:
                self.display_report(message)
            else:
                messagebox.showwarning("Предупреждение", message)
    
    def show_overdue_tasks(self):
        """Показывает просроченные задачи"""
        overdue_tasks = check_overdue_tasks()
        
        report = "ПРОСРОЧЕННЫЕ ЗАДАЧИ\n"
        report += "=" * 50 + "\n\n"
        
        if overdue_tasks:
            for task in overdue_tasks:
                project_name = "Неизвестно"
                for p in self.data["projects"]:
                    if p["id"] == task.get("project_id"):
                        project_name = p["name"]
                        break
                report += f"• {task['title']}\n"
                report += f"  Проект: {project_name}\n"
                report += f"  Срок: {task.get('deadline')}\n"
                report += f"  Ответственный: {task.get('responsible')}\n\n"
        else:
            report += "✅ Просроченных задач нет\n"
        
        self.display_report(report)
    
    def show_project_stats(self):
        """Показывает статистику проектов"""
        report = generate_comprehensive_report(self.user)
        self.display_report(report)
    
    def display_report(self, text):
        """Отображает отчет в текстовом поле"""
        self.report_text.delete(1.0, tk.END)
        self.report_text.insert(1.0, text)
    
    def clear_report(self):
        """Очищает область отчета"""
        self.report_text.delete(1.0, tk.END)
    
    def export_report(self):
        """Экспортирует текущий отчет в файл"""
        report_text = self.report_text.get(1.0, tk.END).strip()
        if not report_text:
            messagebox.showwarning("Предупреждение", "Нет данных для экспорта")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")]
        )
        
        if filename:
            success, message = export_report_to_file(report_text, filename)
            if success:
                messagebox.showinfo("Успех", message)
            else:
                messagebox.showerror("Ошибка", message)

class GanttProjectDialog:
    def __init__(self, parent, data):
        self.top = tk.Toplevel(parent)
        self.data = data
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Выбор проекта для диаграммы Ганта")
        self.top.geometry("400x300")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Выберите проект:").pack(pady=10)
        
        # Список проектов
        self.projects_listbox = tk.Listbox(self.top, height=10)
        scrollbar = ttk.Scrollbar(self.top, orient=tk.VERTICAL, command=self.projects_listbox.yview)
        self.projects_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.projects_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Заполняем список проектов
        for project in self.data["projects"]:
            self.projects_listbox.insert(tk.END, f"{project['id']}: {project['name']}")
        
        # Кнопки
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Выбрать", command=self.select_project).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def select_project(self):
        """Выбирает проект для построения диаграммы"""
        selection = self.projects_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите проект")
            return
        
        selected_text = self.projects_listbox.get(selection[0])
        project_id = int(selected_text.split(":")[0])
        self.result = project_id
        self.top.destroy()

class CustomFieldDialog:
    def __init__(self, parent, key="", value=""):
        self.top = tk.Toplevel(parent)
        self.key = key
        self.value = value
        self.result = None
        self.setup_dialog()
    
    def setup_dialog(self):
        self.top.title("Настраиваемое поле")
        self.top.geometry("300x150")
        self.top.transient(self.top.master)
        self.top.grab_set()
        
        ttk.Label(self.top, text="Ключ:").pack(pady=5)
        self.key_entry = ttk.Entry(self.top, width=30)
        self.key_entry.insert(0, self.key)
        self.key_entry.pack(pady=5)
        
        ttk.Label(self.top, text="Значение:").pack(pady=5)
        self.value_entry = ttk.Entry(self.top, width=30)
        self.value_entry.insert(0, self.value)
        self.value_entry.pack(pady=5)
        
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(pady=10)
        
        ttk.Button(btn_frame, text="Сохранить", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.LEFT, padx=5)
    
    def save(self):
        key = self.key_entry.get().strip()
        value = self.value_entry.get().strip()
        
        if not key:
            messagebox.showwarning("Предупреждение", "Введите ключ")
            return
        
        self.result = (key, value)
        self.top.destroy()

# Главное приложение
class ProjectManagementApp:
    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.data = get_user_related_data(user)
        self.current_project = None
        self.current_task = None
        self.unread_notifications = 0
        
        self.setup_gui()
        
    def setup_gui(self):
        self.root.title(f"Система управления проектами - {self.user['full_name']}")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        self.setup_styles()
        
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.create_header()
        
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.create_projects_tab()
        self.create_tasks_tab()
        self.create_works_tab()
        self.create_notifications_tab()
        
        if self.has_permission("manage_users"):
            self.create_admin_tab()
            
        if self.has_permission("view_reports"):
            self.create_reports_tab()
        
        self.create_status_bar()
        self.update_notifications_count()
    
    def setup_styles(self):
        style = ttk.Style()
        style.configure('Header.TLabel', font=('Arial', 12, 'bold'), background='#e0e0e0')
        style.configure('Title.TLabel', font=('Arial', 14, 'bold'))
        
        style.configure('Draft.TLabel', background='#f8f9fa', foreground='#6c757d')
        style.configure('Review.TLabel', background='#fff3cd', foreground='#856404')
        style.configure('InProgress.TLabel', background='#d1ecf1', foreground='#0c5460')
        style.configure('Completed.TLabel', background='#d4edda', foreground='#155724')
        style.configure('NotCompleted.TLabel', background='#f8d7da', foreground='#721c24')
        
    def create_header(self):
        header_frame = ttk.Frame(self.main_frame)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(header_frame, text=f"Пользователь: {self.user['full_name']}", 
                 style='Header.TLabel').pack(side=tk.LEFT, padx=10)
        ttk.Label(header_frame, text=f"Роль: {self.user['role_display']}", 
                 style='Header.TLabel').pack(side=tk.LEFT, padx=10)
        
        ttk.Button(header_frame, text="Выход", command=self.root.quit).pack(side=tk.RIGHT, padx=10)
        ttk.Button(header_frame, text="Обновить данные", command=self.refresh_data).pack(side=tk.RIGHT, padx=10)
    
    def create_projects_tab(self):
        self.projects_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.projects_frame, text="📂 Проекты")
        
        control_frame = ttk.Frame(self.projects_frame)
        control_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(control_frame, text="Управление проектами", style='Title.TLabel').pack(side=tk.LEFT)
        
        btn_frame = ttk.Frame(control_frame)
        btn_frame.pack(side=tk.RIGHT)
        
        if self.has_permission("edit_projects"):
            ttk.Button(btn_frame, text="➕ Создать проект", 
                      command=self.create_project_dialog).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(btn_frame, text="🔄 Обновить", 
                  command=self.refresh_projects).pack(side=tk.LEFT, padx=5)
        
        self.create_projects_table()
    
    def create_projects_table(self):
        table_frame = ttk.Frame(self.projects_frame)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("ID", "Название", "Статус", "Заказчик", "Руководитель", "Дата начала", "Стоимость")
        self.projects_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)
        
        for col in columns:
            self.projects_tree.heading(col, text=col)
            self.projects_tree.column(col, width=100)
        
        self.projects_tree.column("Название", width=200)
        self.projects_tree.column("Заказчик", width=150)
        
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.projects_tree.yview)
        self.projects_tree.configure(yscrollcommand=scrollbar.set)
        
        self.projects_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.load_projects_data()
        
        action_frame = ttk.Frame(self.projects_frame)
        action_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(action_frame, text="👁️ Просмотреть", 
                  command=self.view_project).pack(side=tk.LEFT, padx=5)
        
        if self.has_permission("edit_projects"):
            ttk.Button(action_frame, text="✏️ Редактировать", 
                      command=self.edit_project_enhanced).pack(side=tk.LEFT, padx=5)
        
        if self.has_permission("change_project_status"):
            ttk.Button(action_frame, text="🔄 Изменить статус", 
                      command=self.change_project_status).pack(side=tk.LEFT, padx=5)
        
        if self.has_permission("delete_projects"):
            ttk.Button(action_frame, text="🗑️ Удалить", 
                      command=self.delete_project).pack(side=tk.LEFT, padx=5)
        
        self.projects_tree.bind("<Double-1>", lambda e: self.view_project())
    
    def load_projects_data(self):
        for item in self.projects_tree.get_children():
            self.projects_tree.delete(item)
        
        for project in self.data["projects"]:
            self.projects_tree.insert("", "end", values=(
                project.get("id", ""),
                project.get("name", ""),
                project.get("status", "черновик"),
                project.get("client", ""),
                project.get("manager", ""),
                project.get("start_date", ""),
                f"{project.get('cost', 0):.2f}"
            ))
    
    def create_tasks_tab(self):
        self.tasks_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.tasks_frame, text="📝 Задачи")
        
        control_frame = ttk.Frame(self.tasks_frame)
        control_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(control_frame, text="Управление задачами", style='Title.TLabel').pack(side=tk.LEFT)
        
        btn_frame = ttk.Frame(control_frame)
        btn_frame.pack(side=tk.RIGHT)
        
        if self.has_permission("edit_tasks"):
            ttk.Button(btn_frame, text="➕ Создать задачу", 
                      command=self.create_task_dialog).pack(side=tk.LEFT, padx=5)
            ttk.Button(btn_frame, text="🛠️ Разбить на работы", 
                      command=self.break_task_into_works).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(btn_frame, text="🔄 Обновить", 
                  command=self.refresh_tasks).pack(side=tk.LEFT, padx=5)
        
        self.create_tasks_table()
    
    def create_tasks_table(self):
        table_frame = ttk.Frame(self.tasks_frame)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("ID", "Название", "Статус", "Проект", "Ответственный", "Срок", "Приоритет")
        self.tasks_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)
        
        for col in columns:
            self.tasks_tree.heading(col, text=col)
            self.tasks_tree.column(col, width=100)
        
        self.tasks_tree.column("Название", width=200)
        
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tasks_tree.yview)
        self.tasks_tree.configure(yscrollcommand=scrollbar.set)
        
        self.tasks_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.load_tasks_data()
        
        action_frame = ttk.Frame(self.tasks_frame)
        action_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(action_frame, text="👁️ Просмотреть", 
                  command=self.view_task).pack(side=tk.LEFT, padx=5)
        
        if self.has_permission("edit_tasks"):
            ttk.Button(action_frame, text="✏️ Редактировать", 
                      command=self.edit_task_enhanced).pack(side=tk.LEFT, padx=5)
        
        if self.has_permission("change_task_status"):
            ttk.Button(action_frame, text="🔄 Изменить статус", 
                      command=self.change_task_status).pack(side=tk.LEFT, padx=5)
        
        if self.has_permission("delete_tasks"):
            ttk.Button(action_frame, text="🗑️ Удалить", 
                      command=self.delete_task).pack(side=tk.LEFT, padx=5)
        
        self.tasks_tree.bind("<Double-1>", lambda e: self.view_task())
    
    def load_tasks_data(self):
        for item in self.tasks_tree.get_children():
            self.tasks_tree.delete(item)
        
        for task in self.data.get("tasks", []):
            project_name = "Неизвестно"
            for project in self.data["projects"]:
                if project.get("id") == task.get("project_id"):
                    project_name = project.get("name", "")
                    break
            
            self.tasks_tree.insert("", "end", values=(
                task.get("id", ""),
                task.get("title", ""),
                task.get("status", "черновик"),
                project_name,
                task.get("responsible", ""),
                task.get("deadline", ""),
                task.get("priority", "")
            ))
    
    def create_works_tab(self):
        self.works_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.works_frame, text="🔨 Работы")
        
        control_frame = ttk.Frame(self.works_frame)
        control_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(control_frame, text="Управление работами", style='Title.TLabel').pack(side=tk.LEFT)
        
        btn_frame = ttk.Frame(control_frame)
        btn_frame.pack(side=tk.RIGHT)
        
        ttk.Button(btn_frame, text="🔄 Обновить", 
                  command=self.refresh_works).pack(side=tk.LEFT, padx=5)
        
        self.create_works_table()
    
    def create_works_table(self):
        table_frame = ttk.Frame(self.works_frame)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("ID", "Название", "Статус", "Задача", "Исполнитель", "Создатель")
        self.works_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)
        
        for col in columns:
            self.works_tree.heading(col, text=col)
            self.works_tree.column(col, width=100)
        
        self.works_tree.column("Название", width=200)
        
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.works_tree.yview)
        self.works_tree.configure(yscrollcommand=scrollbar.set)
        
        self.works_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.load_works_data()
        
        action_frame = ttk.Frame(self.works_frame)
        action_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(action_frame, text="👁️ Просмотреть", 
                  command=self.view_work).pack(side=tk.LEFT, padx=5)
        
        if self.has_permission("edit_works"):
            ttk.Button(action_frame, text="✏️ Редактировать", 
                      command=self.edit_work_enhanced).pack(side=tk.LEFT, padx=5)
        
        if self.has_permission("change_work_status"):
            ttk.Button(action_frame, text="🔄 Изменить статус", 
                      command=self.change_work_status).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(action_frame, text="✅ Выполнить", 
                  command=self.complete_work).pack(side=tk.LEFT, padx=5)
        
        self.works_tree.bind("<Double-1>", lambda e: self.view_work())
    
    def load_works_data(self):
        for item in self.works_tree.get_children():
            self.works_tree.delete(item)
        
        for work in self.data.get("works", []):
            task_title = "Неизвестно"
            for task in self.data.get("tasks", []):
                if task.get("id") == work.get("task_id"):
                    task_title = task.get("title", "")
                    break
            
            self.works_tree.insert("", "end", values=(
                work.get("id", ""),
                work.get("title", ""),
                work.get("status", "черновик"),
                task_title,
                work.get("executor", ""),
                work.get("created_by", "")
            ))
    
    def create_notifications_tab(self):
        self.notifications_frame = ttk.Frame(self.notebook)
        tab_text = "🔔 Уведомления"
        self.notebook.add(self.notifications_frame, text=tab_text)
        self.notifications_tab_text = tab_text
        
        control_frame = ttk.Frame(self.notifications_frame)
        control_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(control_frame, text="Уведомления системы", style='Title.TLabel').pack(side=tk.LEFT)
        
        btn_frame = ttk.Frame(control_frame)
        btn_frame.pack(side=tk.RIGHT)
        
        ttk.Button(btn_frame, text="🔄 Проверить", 
                  command=self.check_notifications).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="✅ Отметить как прочитанные", 
                  command=self.mark_all_as_read).pack(side=tk.LEFT, padx=5)
        
        self.create_notifications_table()
    
    def create_notifications_table(self):
        table_frame = ttk.Frame(self.notifications_frame)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("Дата", "Тип", "Сообщение", "Статус")
        self.notifications_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)
        
        for col in columns:
            self.notifications_tree.heading(col, text=col)
            self.notifications_tree.column(col, width=150)
        
        self.notifications_tree.column("Сообщение", width=300)
        
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.notifications_tree.yview)
        self.notifications_tree.configure(yscrollcommand=scrollbar.set)
        
        self.notifications_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.load_notifications_data()
    
    def load_notifications_data(self):
        for item in self.notifications_tree.get_children():
            self.notifications_tree.delete(item)
        
        user_notifications = [n for n in self.data.get("notifications", []) 
                            if n.get("user") == self.user["username"]]
        
        for notification in user_notifications:
            status = "✅ Прочитано" if notification.get("read", False) else "🔔 Новое"
            self.notifications_tree.insert("", "end", values=(
                notification.get("date", ""),
                notification.get("type", ""),
                notification.get("message", ""),
                status
            ))
    
    def update_notifications_count(self):
        user_notifications = [n for n in self.data.get("notifications", []) 
                            if n.get("user") == self.user["username"] and not n.get("read", False)]
        self.unread_notifications = len(user_notifications)
        
        tab_text = "🔔 Уведомления"
        if self.unread_notifications > 0:
            tab_text = f"🔔 Уведомления ({self.unread_notifications})"
        
        for i in range(self.notebook.index("end")):
            if "Уведомления" in self.notebook.tab(i, "text"):
                self.notebook.tab(i, text=tab_text)
                break
    
    def check_notifications(self):
        from datetime import datetime
        
        overdue_tasks = []
        for task in self.data.get("tasks", []):
            if task.get("deadline") and task.get("status") not in ["выполнено", "не_выполнено"]:
                try:
                    deadline = datetime.strptime(task["deadline"], '%Y-%m-%d').date()
                    if deadline < datetime.now().date():
                        overdue_tasks.append(task)
                except ValueError:
                    continue
        
        for task in overdue_tasks:
            self.create_notification(
                task.get("responsible"),
                "Просроченная задача",
                f"Задача '{task.get('title')}' просрочена. Срок: {task.get('deadline')}"
            )
        
        if self.user["role"] == "исполнитель":
            user_works = [w for w in self.data.get("works", []) 
                         if w.get("executor") == self.user["username"] and 
                         w.get("status") not in ["выполнено", "не_выполнено"]]
            
            for work in user_works:
                task = next((t for t in self.data.get("tasks", []) if t["id"] == work.get("task_id")), None)
                if task and task.get("deadline"):
                    try:
                        deadline = datetime.strptime(task["deadline"], '%Y-%m-%d').date()
                        days_until_deadline = (deadline - datetime.now().date()).days
                        if 0 <= days_until_deadline <= 3:
                            self.create_notification(
                                self.user["username"],
                                "Скоро срок",
                                f"Работа '{work.get('title')}' должна быть завершена через {days_until_deadline} дней"
                            )
                    except ValueError:
                        continue
        
        self.refresh_data()
        messagebox.showinfo("Уведомления", "Проверка уведомлений завершена")
    
    def create_notification(self, username, notification_type, message):
        data = load_data()
        
        notification = {
            "id": len(data.get("notifications", [])) + 1,
            "user": username,
            "type": notification_type,
            "message": message,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "read": False
        }
        
        if "notifications" not in data:
            data["notifications"] = []
        
        existing = [n for n in data["notifications"] 
                   if n.get("user") == username and n.get("message") == message and not n.get("read")]
        if not existing:
            data["notifications"].append(notification)
            save_data(data)
    
    def mark_all_as_read(self):
        for notification in self.data.get("notifications", []):
            if notification.get("user") == self.user["username"]:
                notification["read"] = True
        
        save_data(self.data)
        self.refresh_data()
        messagebox.showinfo("Уведомления", "Все уведомления отмечены как прочитанные")
    
    def create_admin_tab(self):
        self.admin_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.admin_frame, text="🔧 Администрирование")
        
        ttk.Label(self.admin_frame, text="Управление пользователями", style='Title.TLabel').pack(pady=20)
        
        self.create_users_table()
    
    def create_users_table(self):
        table_frame = ttk.Frame(self.admin_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        columns = ("Логин", "ФИО", "Роль", "Статус", "Права")
        self.users_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=10)
        
        for col in columns:
            self.users_tree.heading(col, text=col)
            self.users_tree.column(col, width=120)
        
        self.users_tree.column("ФИО", width=150)
        
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.users_tree.yview)
        self.users_tree.configure(yscrollcommand=scrollbar.set)
        
        self.users_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.load_users_data()
        
        action_frame = ttk.Frame(self.admin_frame)
        action_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(action_frame, text="➕ Создать пользователя", 
                  command=self.create_user_dialog).pack(side=tk.LEFT, padx=5)
        ttk.Button(action_frame, text="✏️ Редактировать", 
                  command=self.edit_user).pack(side=tk.LEFT, padx=5)
        ttk.Button(action_frame, text="🚫 Блокировать", 
                  command=self.toggle_user_status_dialog).pack(side=tk.LEFT, padx=5)  # Изменено название
        ttk.Button(action_frame, text="🗑️ Удалить", 
                  command=self.delete_user).pack(side=tk.LEFT, padx=5)
        ttk.Button(action_frame, text="🔄 Обновить", 
                  command=self.refresh_users).pack(side=tk.LEFT, padx=5)
    
    def load_users_data(self):
        for item in self.users_tree.get_children():
            self.users_tree.delete(item)
        
        for user in self.data["users"]:
            active_permissions = sum(user.get("permissions", {}).values())
            total_permissions = len(user.get("permissions", {}))
            status = "✅ Активен" if user.get("is_active", True) else "🚫 Заблокирован"
            
            self.users_tree.insert("", "end", values=(
                user.get("username", ""),
                user.get("full_name", ""),
                user.get("role", ""),
                status,
                f"{active_permissions}/{total_permissions}"
            ))
    
    def create_reports_tab(self):
        self.reports_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.reports_frame, text="📊 Отчеты")
        
        ttk.Label(self.reports_frame, text="Отчеты и аналитика", style='Title.TLabel').pack(pady=20)
        
        reports_frame = ttk.Frame(self.reports_frame)
        reports_frame.pack(pady=20)
        
        ttk.Button(reports_frame, text="📅 Проверить сроки", 
                  command=self.check_deadlines, width=20).pack(pady=10)
        ttk.Button(reports_frame, text="📈 Статистика проектов", 
                  command=self.show_projects_stats, width=20).pack(pady=10)
        ttk.Button(reports_frame, text="📋 Общий отчет", 
                  command=self.generate_full_report, width=20).pack(pady=10)
        ttk.Button(reports_frame, text="📊 Расширенная отчетность", 
                  command=self.show_advanced_reports, width=20).pack(pady=10)
        
        self.reports_text = tk.Text(self.reports_frame, height=15, width=80)
        self.reports_text.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
        
        export_frame = ttk.Frame(self.reports_frame)
        export_frame.pack(pady=10)
        
        ttk.Button(export_frame, text="Экспорт отчета", 
                  command=self.export_report).pack(side=tk.LEFT, padx=5)
        ttk.Button(export_frame, text="Очистить", 
                  command=self.clear_report).pack(side=tk.LEFT, padx=5)
    
    def create_status_bar(self):
        status_frame = ttk.Frame(self.main_frame)
        status_frame.pack(fill=tk.X, pady=5)
        
        self.status_label = ttk.Label(status_frame, text="Готов к работе")
        self.status_label.pack(side=tk.LEFT)
    
    def has_permission(self, permission):
        return self.user.get("permissions", {}).get(permission, False)
    
    def refresh_data(self):
        self.data = get_user_related_data(self.user)
        self.refresh_projects()
        self.refresh_tasks()
        self.refresh_works()
        self.refresh_users()
        self.refresh_notifications()
        self.status_label.config(text="Данные обновлены")
    
    def refresh_projects(self):
        self.load_projects_data()
        self.status_label.config(text="Список проектов обновлен")
    
    def refresh_tasks(self):
        self.load_tasks_data()
        self.status_label.config(text="Список задач обновлен")
    
    def refresh_works(self):
        self.load_works_data()
        self.status_label.config(text="Список работ обновлен")
    
    def refresh_users(self):
        if hasattr(self, 'users_tree'):
            self.load_users_data()
            self.status_label.config(text="Список пользователей обновлен")
    
    def refresh_notifications(self):
        if hasattr(self, 'notifications_tree'):
            self.load_notifications_data()
            self.update_notifications_count()
            self.status_label.config(text="Уведомления обновлены")
    
    # Методы действий
    def create_project_dialog(self):
        dialog = ProjectDialog(self.root, self.user)
        self.root.wait_window(dialog.top)
        if dialog.result:
            self.refresh_data()
    
    def create_task_dialog(self):
        dialog = TaskDialog(self.root, self.user, self.data)
        self.root.wait_window(dialog.top)
        if dialog.result:
            self.refresh_data()
    
    def create_user_dialog(self):
        dialog = UserDialog(self.root, self.user)
        self.root.wait_window(dialog.top)
        if dialog.result:
            self.refresh_data()
    
    def view_project(self):
        selection = self.projects_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите проект для просмотра")
            return
        
        item = self.projects_tree.item(selection[0])
        project_id = item["values"][0]
        
        project = next((p for p in self.data["projects"] if p["id"] == project_id), None)
        if project:
            # Исправлено: открывается диалоговое окно вместо messagebox
            dialog = ProjectDetailsDialog(self.root, project, self.data)
            self.root.wait_window(dialog.top)
    
    def show_project_details(self, project):
        # Эта функция больше не используется, так как теперь используется диалоговое окно
        pass
    
    def edit_project(self):
        selection = self.projects_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите проект для редактирования")
            return
        
        item = self.projects_tree.item(selection[0])
        project_id = item["values"][0]
        
        project = next((p for p in self.data["projects"] if p["id"] == project_id), None)
        if project:
            # Проверяем права на редактирование
            if not self.can_edit_project(project):
                messagebox.showerror("Ошибка", "Редактирование запрещено: проект в статусе, не позволяющем редактирование")
                return
            
            dialog = EditProjectDialog(self.root, project)
            self.root.wait_window(dialog.top)
            if dialog.result:
                save_data(self.data)
                self.refresh_projects()
                self.status_label.config(text="Проект обновлен")
    
    def can_edit_project(self, project):
        """Проверяет можно ли редактировать проект"""
        if self.has_permission("force_edit"):
            return True
        return project.get("status") in ["черновик", "на_рассмотрении"]
    
    def delete_project(self):
        selection = self.projects_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите проект для удаления")
            return
        
        item = self.projects_tree.item(selection[0])
        project_id = item["values"][0]
        project_name = item["values"][1]
        
        project = next((p for p in self.data["projects"] if p["id"] == project_id), None)
        if project:
            # Проверяем есть ли связанные задачи
            project_tasks = [t for t in self.data.get("tasks", []) if t.get("project_id") == project_id]
            if project_tasks:
                messagebox.showerror("Ошибка", f"Нельзя удалить проект: есть связанные задачи ({len(project_tasks)} шт.)")
                return
            
            confirm = messagebox.askyesno("Подтверждение", f"Вы уверены, что хотите удалить проект '{project_name}'?")
            if confirm:
                self.data["projects"] = [p for p in self.data["projects"] if p["id"] != project_id]
                save_data(self.data)
                self.refresh_projects()
                self.status_label.config(text="Проект удален")
    
    def change_project_status(self):
        selection = self.projects_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите проект для изменения статуса")
            return
        
        item = self.projects_tree.item(selection[0])
        project_id = item["values"][0]
        
        project = next((p for p in self.data["projects"] if p["id"] == project_id), None)
        if project:
            dialog = ChangeStatusDialog(self.root, "проекта", PROJECT_STATUSES, project.get("status"))
            self.root.wait_window(dialog.top)
            if dialog.result:
                new_status = dialog.result
                
                # Проверяем можно ли закрыть проект
                if new_status in ["выполнено", "не_выполнено"]:
                    project_tasks = [t for t in self.data.get("tasks", []) if t.get("project_id") == project_id]
                    unfinished_tasks = [t for t in project_tasks if t.get("status") not in ["выполнено", "не_выполнено"]]
                    
                    if unfinished_tasks:
                        task_list = "\n".join([f"- {t.get('title')}" for t in unfinished_tasks])
                        messagebox.showerror("Ошибка", 
                            f"Нельзя закрыть проект: есть незавершенные задачи:\n{task_list}")
                        return
                
                project["status"] = new_status
                
                # Если проект завершен, устанавливаем фактическую дату завершения
                if new_status in ["выполнено", "не_выполнено"]:
                    from datetime import datetime
                    project["actual_end"] = datetime.now().strftime("%Y-%m-%d")
                
                save_data(self.data)
                self.refresh_projects()
                self.status_label.config(text=f"Статус проекта изменен на: {new_status}")
    
    def view_task(self):
        selection = self.tasks_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите задачу для просмотра")
            return
        
        item = self.tasks_tree.item(selection[0])
        task_id = item["values"][0]
        
        task = next((t for t in self.data.get("tasks", []) if t["id"] == task_id), None)
        if task:
            self.show_task_details(task)
    
    def show_task_details(self, task):
        # Используем диалоговое окно вместо messagebox
        dialog = TaskDetailsDialog(self.root, task, self.data)
        self.root.wait_window(dialog.top)
    
    def edit_task(self):
        selection = self.tasks_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите задачу для редактирования")
            return
        
        item = self.tasks_tree.item(selection[0])
        task_id = item["values"][0]
        
        task = next((t for t in self.data.get("tasks", []) if t["id"] == task_id), None)
        if task:
            # Проверяем можно ли редактировать задачу
            if not self.can_edit_task(task):
                messagebox.showerror("Ошибка", "Редактирование запрещено: задача в статусе, не позволяющем редактирование")
                return
            
            dialog = EditTaskDialog(self.root, task, self.data)
            self.root.wait_window(dialog.top)
            if dialog.result:
                save_data(self.data)
                self.refresh_tasks()
                self.status_label.config(text="Задача обновлена")
    
    def can_edit_task(self, task):
        """Проверяет можно ли редактировать задачу"""
        if self.has_permission("force_edit"):
            return True
        
        # Получаем проект задачи
        project = next((p for p in self.data["projects"] if p["id"] == task.get("project_id")), None)
        
        # Если проект закрыт, нельзя редактировать задачу
        if project and project.get("status") in ["выполнено", "не_выполнено"]:
            return False
        
        return task.get("status") in ["черновик", "на_рассмотрении"]
    
    def delete_task(self):
        selection = self.tasks_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите задачу для удаления")
            return
        
        item = self.tasks_tree.item(selection[0])
        task_id = item["values"][0]
        task_name = item["values"][1]
        
        task = next((t for t in self.data.get("tasks", []) if t["id"] == task_id), None)
        if task:
            # Проверяем есть ли связанные работы
            task_works = [w for w in self.data.get("works", []) if w.get("task_id") == task_id]
            if task_works:
                messagebox.showerror("Ошибка", f"Нельзя удалить задачу: есть связанные работы ({len(task_works)} шт.)")
                return
            
            confirm = messagebox.askyesno("Подтверждение", f"Вы уверены, что хотите удалить задачу '{task_name}'?")
            if confirm:
                self.data["tasks"] = [t for t in self.data.get("tasks", []) if t["id"] != task_id]
                save_data(self.data)
                self.refresh_tasks()
                self.status_label.config(text="Задача удалена")
    
    def change_task_status(self):
        selection = self.tasks_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите задачу для изменения статуса")
            return
        
        item = self.tasks_tree.item(selection[0])
        task_id = item["values"][0]
        
        task = next((t for t in self.data.get("tasks", []) if t["id"] == task_id), None)
        if task:
            dialog = ChangeStatusDialog(self.root, "задачи", TASK_STATUSES, task.get("status"))
            self.root.wait_window(dialog.top)
            if dialog.result:
                new_status = dialog.result
                
                # Проверяем можно ли закрыть задачу
                if new_status in ["выполнено", "не_выполнено"]:
                    task_works = [w for w in self.data.get("works", []) if w.get("task_id") == task_id]
                    unfinished_works = [w for w in task_works if w.get("status") not in ["выполнено", "не_выполнено"]]
                    
                    if unfinished_works:
                        work_list = "\n".join([f"- {w.get('title')}" for w in unfinished_works])
                        messagebox.showerror("Ошибка", 
                            f"Нельзя закрыть задачу: есть незавершенные работы:\n{work_list}")
                        return
                
                task["status"] = new_status
                save_data(self.data)
                self.refresh_tasks()
                self.status_label.config(text=f"Статус задачи изменен на: {new_status}")
    
    def break_task_into_works(self):
        selection = self.tasks_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите задачу для разбивки на работы")
            return
        
        item = self.tasks_tree.item(selection[0])
        task_id = item["values"][0]
        task_name = item["values"][1]
        
        task = next((t for t in self.data.get("tasks", []) if t["id"] == task_id), None)
        if task:
            # Проверяем что пользователь является ответственным
            if task.get("responsible") != self.user["username"] and not self.has_permission("force_edit"):
                messagebox.showerror("Ошибка", "Вы не являетесь ответственным исполнителем этой задачи")
                return
            
            dialog = BreakTaskDialog(self.root, task, self.data, self.user)
            self.root.wait_window(dialog.top)
            if dialog.result:
                self.refresh_data()
                self.status_label.config(text="Задача разбита на работы")
    
    def view_work(self):
        selection = self.works_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите работу для просмотра")
            return
        
        item = self.works_tree.item(selection[0])
        work_id = item["values"][0]
        
        work = next((w for w in self.data.get("works", []) if w["id"] == work_id), None)
        if work:
            self.show_work_details(work)
    
    def show_work_details(self, work):
        # Используем диалоговое окно вместо messagebox
        dialog = WorkDetailsDialog(self.root, work, self.data)
        self.root.wait_window(dialog.top)
    
    def edit_work(self):
        selection = self.works_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите работу для редактирования")
            return
        
        item = self.works_tree.item(selection[0])
        work_id = item["values"][0]
        
        work = next((w for w in self.data.get("works", []) if w["id"] == work_id), None)
        if work:
            # Проверяем можно ли редактировать работу
            if not self.can_edit_work(work):
                messagebox.showerror("Ошибка", "Редактирование запрещено: работа в статусе, не позволяющем редактирование")
                return
            
            dialog = EditWorkDialog(self.root, work, self.data)
            self.root.wait_window(dialog.top)
            if dialog.result:
                save_data(self.data)
                self.refresh_works()
                self.status_label.config(text="Работа обновлена")
    
    def can_edit_work(self, work):
        """Проверяет можно ли редактировать работу"""
        if self.has_permission("force_edit"):
            return True
        
        # Получаем задачу и проект
        task = next((t for t in self.data.get("tasks", []) if t["id"] == work.get("task_id")), None)
        
        if task:
            project = next((p for p in self.data["projects"] if p["id"] == task.get("project_id")), None)
            # Если проект закрыт, нельзя редактировать работу
            if project and project.get("status") in ["выполнено", "не_выполнено"]:
                return False
        
        return work.get("status") in ["черновик", "на_рассмотрении"]
    
    def change_work_status(self):
        selection = self.works_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите работу для изменения статуса")
            return
        
        item = self.works_tree.item(selection[0])
        work_id = item["values"][0]
        
        work = next((w for w in self.data.get("works", []) if w["id"] == work_id), None)
        if work:
            dialog = ChangeStatusDialog(self.root, "работы", WORK_STATUSES, work.get("status"))
            self.root.wait_window(dialog.top)
            if dialog.result:
                work["status"] = dialog.result
                save_data(self.data)
                self.refresh_works()
                self.status_label.config(text=f"Статус работы изменен на: {dialog.result}")
    
    def complete_work(self):
        selection = self.works_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите работу для отметки выполнения")
            return
        
        item = self.works_tree.item(selection[0])
        work_id = item["values"][0]
        
        work = next((w for w in self.data.get("works", []) if w["id"] == work_id), None)
        if work:
            # Проверяем что пользователь является исполнителем
            if work.get("executor") != self.user["username"] and not self.has_permission("force_edit"):
                messagebox.showerror("Ошибка", "Вы не являетесь исполнителем этой работы")
                return
            
            work["status"] = "выполнено"
            save_data(self.data)
            self.refresh_works()
            self.status_label.config(text="Работа отмечена как выполненная")
            
            # Проверяем можно ли закрыть задачу
            self.check_task_completion(work.get("task_id"))
    
    def check_task_completion(self, task_id):
        """Проверяет можно ли закрыть задачу (все работы завершены)"""
        task_works = [w for w in self.data.get("works", []) if w.get("task_id") == task_id]
        
        if all(work.get("status") in ["выполнено", "не_выполнено"] for work in task_works):
            task = next((t for t in self.data.get("tasks", []) if t["id"] == task_id), None)
            if task and task.get("status") not in ["выполнено", "не_выполнено"]:
                messagebox.showinfo("Информация", 
                    f"Все работы задачи '{task.get('title')}' завершены. Задачу можно закрыть.")
    
    def toggle_user_status_dialog(self):
        """Диалоговое окно для блокировки/разблокировки пользователя (с галочкой)"""
        selection = self.users_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите пользователя для блокировки/разблокировки")
            return
        
        item = self.users_tree.item(selection[0])
        username = item["values"][0]
        current_status = item["values"][3]
        
        if username == self.user["username"]:
            messagebox.showerror("Ошибка", "Вы не можете заблокировать свой собственный аккаунт!")
            return
        
        if username == "admin":
            messagebox.showerror("Ошибка", "Нельзя заблокировать системного администратора!")
            return
        
        # Создаем диалоговое окно с галочкой
        dialog = tk.Toplevel(self.root)
        dialog.title("Изменение статуса пользователя")
        dialog.geometry("300x150")
        dialog.transient(self.root)
        dialog.grab_set()
        
        ttk.Label(dialog, text=f"Пользователь: {username}").pack(pady=10)
        ttk.Label(dialog, text=f"Текущий статус: {current_status}").pack(pady=5)
        
        # Галочка для блокировки
        self.block_var = tk.BooleanVar()
        if "Заблокирован" in current_status:
            self.block_var.set(False)  # Разблокировать
            ttk.Checkbutton(dialog, text="Разблокировать пользователя", variable=self.block_var).pack(pady=10)
        else:
            self.block_var.set(True)  # Заблокировать
            ttk.Checkbutton(dialog, text="Заблокировать пользователя", variable=self.block_var).pack(pady=10)
        
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(pady=10)
        
        def apply_change():
            should_block = self.block_var.get()
            user = next((u for u in self.data["users"] if u["username"] == username), None)
            
            if user:
                if should_block:
                    user["is_active"] = False
                    message = f"Пользователь {username} заблокирован"
                else:
                    user["is_active"] = True
                    message = f"Пользователь {username} разблокирован"
                
                save_data(self.data)
                self.refresh_users()
                self.status_label.config(text=message)
                dialog.destroy()
        
        ttk.Button(btn_frame, text="Применить", command=apply_change).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=dialog.destroy).pack(side=tk.LEFT, padx=5)
    
    def edit_user(self):
        selection = self.users_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите пользователя для редактирования")
            return
        
        item = self.users_tree.item(selection[0])
        username = item["values"][0]
        
        if username == "admin":
            messagebox.showerror("Ошибка", "Нельзя редактировать системного администратора!")
            return
        
        user = next((u for u in self.data["users"] if u["username"] == username), None)
        if user:
            dialog = EditUserDialog(self.root, user)
            self.root.wait_window(dialog.top)
            if dialog.result:
                save_data(self.data)
                self.refresh_users()
                self.status_label.config(text="Пользователь обновлен")
    
    def delete_user(self):
        selection = self.users_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите пользователя для удаления")
            return
        
        item = self.users_tree.item(selection[0])
        username = item["values"][0]
        
        if username == self.user["username"]:
            messagebox.showerror("Ошибка", "Вы не можете удалить свой собственный аккаунт!")
            return
        
        if username == "admin":
            messagebox.showerror("Ошибка", "Нельзя удалить системного администратора!")
            return
        
        confirm = messagebox.askyesno("Подтверждение", f"Вы уверены, что хотите удалить пользователя '{username}'?")
        if confirm:
            self.data["users"] = [u for u in self.data["users"] if u["username"] != username]
            save_data(self.data)
            self.refresh_users()
            self.status_label.config(text="Пользователь удален")
    
    def manage_permissions(self):
        selection = self.users_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите пользователя для настройки прав")
            return
        
        item = self.users_tree.item(selection[0])
        username = item["values"][0]
        
        user = next((u for u in self.data["users"] if u["username"] == username), None)
        if user:
            dialog = ManagePermissionsDialog(self.root, user)
            self.root.wait_window(dialog.top)
            if dialog.result:
                save_data(self.data)
                self.refresh_users()
                self.status_label.config(text="Права пользователя обновлены")
    
    def check_deadlines(self):
        from datetime import datetime
        
        today = datetime.now().date()
        report = "ОТЧЕТ О ПРОВЕРКЕ СРОКОВ\n\n"
        
        # Проверяем проекты
        overdue_projects = []
        for project in self.data["projects"]:
            if project.get("planned_end") and project.get("status") not in ["выполнено", "не_выполнено"]:
                try:
                    deadline = datetime.strptime(project["planned_end"], '%Y-%m-%d').date()
                    if deadline < today:
                        overdue_projects.append(project)
                except ValueError:
                    continue
        
        if overdue_projects:
            report += "⚠️ ПРОСРОЧЕННЫЕ ПРОЕКТЫ:\n"
            for project in overdue_projects:
                report += f"   - {project.get('name', '')} (срок: {project.get('planned_end', '')})\n"
        else:
            report += "✅ Просроченных проектов нет\n"
        
        report += "\n"
        
        # Проверяем задачи
        overdue_tasks = []
        for task in self.data.get("tasks", []):
            if task.get("deadline") and task.get("status") not in ["выполнено", "не_выполнено"]:
                try:
                    deadline = datetime.strptime(task["deadline"], '%Y-%m-%d').date()
                    if deadline < today:
                        overdue_tasks.append(task)
                except ValueError:
                    continue
        
        if overdue_tasks:
            report += "⚠️ ПРОСРОЧЕННЫЕ ЗАДАЧИ:\n"
            for task in overdue_tasks:
                report += f"   - {task.get('title', '')} (срок: {task.get('deadline', '')})\n"
        else:
            report += "✅ Просроченных задач нет\n"
        
        self.reports_text.delete(1.0, tk.END)
        self.reports_text.insert(1.0, report)
    
    def show_projects_stats(self):
        stats = "СТАТИСТИКА ПРОЕКТОВ\n\n"
        
        total_projects = len(self.data["projects"])
        completed_projects = len([p for p in self.data["projects"] if p.get("status") in ["выполнено", "не_выполнено"]])
        active_projects = total_projects - completed_projects
        
        stats += f"Всего проектов: {total_projects}\n"
        stats += f"Активных проектов: {active_projects}\n"
        stats += f"Завершенных проектов: {completed_projects}\n"
        
        # Статистика по статусам
        status_stats = {}
        for project in self.data["projects"]:
            status = project.get("status", "черновик")
            status_stats[status] = status_stats.get(status, 0) + 1
        
        stats += "\nСтатистика по статусам:\n"
        for status, count in status_stats.items():
            stats += f"  {status}: {count}\n"
        
        self.reports_text.delete(1.0, tk.END)
        self.reports_text.insert(1.0, stats)
    
    def generate_full_report(self):
        report = "ПОЛНЫЙ ОТЧЕТ СИСТЕМЫ\n\n"
        
        report += f"Пользователей в системе: {len(self.data['users'])}\n"
        report += f"Проектов: {len(self.data['projects'])}\n"
        report += f"Задач: {len(self.data.get('tasks', []))}\n"
        report += f"Работ: {len(self.data.get('works', []))}\n\n"
        
        # Статистика пользователей по ролям
        role_stats = {}
        for user in self.data["users"]:
            role = user.get("role", "неизвестно")
            role_stats[role] = role_stats.get(role, 0) + 1
        
        report += "Пользователи по ролям:\n"
        for role, count in role_stats.items():
            report += f"  {role}: {count}\n"
        
        self.reports_text.delete(1.0, tk.END)
        self.reports_text.insert(1.0, report)

    # РАСШИРЕННЫЕ ФУНКЦИИ
    
    def edit_project_enhanced(self):
        """Расширенное редактирование проекта с вложениями (без настраиваемых полей)"""
        selection = self.projects_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите проект для редактирования")
            return
        
        item = self.projects_tree.item(selection[0])
        project_id = item["values"][0]
        
        project = next((p for p in self.data["projects"] if p["id"] == project_id), None)
        if project:
            # Проверяем права на редактирование
            if not self.can_edit_project(project):
                messagebox.showerror("Ошибка", "Редактирование запрещено: проект в статусе, не позволяющем редактирование")
                return
            
            dialog = EnhancedProjectDialog(self.root, project, self.user)
            self.root.wait_window(dialog.top)
            if dialog.result:
                save_data(self.data)
                self.refresh_projects()
                self.status_label.config(text="Проект обновлен")
    
    def edit_task_enhanced(self):
        """Расширенное редактирование задачи с вложениями"""
        selection = self.tasks_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите задачу для редактирования")
            return
        
        item = self.tasks_tree.item(selection[0])
        task_id = item["values"][0]
        
        task = next((t for t in self.data.get("tasks", []) if t["id"] == task_id), None)
        if task:
            # Проверяем можно ли редактировать задачу
            if not self.can_edit_task(task):
                messagebox.showerror("Ошибка", "Редактирование запрещено: задача в статусе, не позволяющем редактирование")
                return
            
            dialog = EnhancedTaskDialog(self.root, task, self.data, self.user)
            self.root.wait_window(dialog.top)
            if dialog.result:
                save_data(self.data)
                self.refresh_tasks()
                self.status_label.config(text="Задача обновлена")
    
    def edit_work_enhanced(self):
        """Расширенное редактирование работы с вложениями"""
        selection = self.works_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите работу для редактирования")
            return
        
        item = self.works_tree.item(selection[0])
        work_id = item["values"][0]
        
        work = next((w for w in self.data.get("works", []) if w["id"] == work_id), None)
        if work:
            # Проверяем можно ли редактировать работу
            if not self.can_edit_work(work):
                messagebox.showerror("Ошибка", "Редактирование запрещено: работа в статусе, не позволяющем редактирование")
                return
            
            dialog = EnhancedWorkDialog(self.root, work, self.data, self.user)
            self.root.wait_window(dialog.top)
            if dialog.result:
                save_data(self.data)
                self.refresh_works()
                self.status_label.config(text="Работа обновлена")
    
    def show_gantt_dialog(self):
        """Показывает диалог для построения диаграммы Ганта"""
        selection = self.projects_tree.selection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите проект для построения диаграммы")
            return
        
        item = self.projects_tree.item(selection[0])
        project_id = item["values"][0]
        
        success, message = generate_gantt_chart(project_id)
        if success:
            messagebox.showinfo("Диаграмма Ганта", message)
        else:
            messagebox.showerror("Ошибка", message)
    
    def show_advanced_reports(self):
        """Показывает диалог расширенной отчетности"""
        dialog = AdvancedReportsDialog(self.root, self.user, self.data)
        self.root.wait_window(dialog.top)
    
    def export_report(self):
        """Экспортирует текущий отчет в файл"""
        report_text = self.reports_text.get(1.0, tk.END).strip()
        if not report_text:
            messagebox.showwarning("Предупреждение", "Нет данных для экспорта")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")]
        )
        
        if filename:
            success, message = export_report_to_file(report_text, filename)
            if success:
                messagebox.showinfo("Успех", message)
                self.status_label.config(text="Отчет экспортирован")
            else:
                messagebox.showerror("Ошибка", message)
    
    def clear_report(self):
        """Очищает область отчета"""
        self.reports_text.delete(1.0, tk.END)

# Стартовое меню
class StartMenu:
    def __init__(self, root):
        self.root = root
        self.user = None
        self.setup_menu()
    
    def setup_menu(self):
        self.root.title("Система управления проектами - Стартовое меню")
        self.root.geometry("800x600")
        self.root.configure(bg='#f0f0f0')
        
        self.center_window()
        
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        self.create_header()
        self.create_login_section()
        self.create_info_section()
        self.create_status_bar()
    
    def center_window(self):
        self.root.update_idletasks()
        width = 800
        height = 600
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_header(self):
        header_frame = ttk.Frame(self.main_frame)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        logo_frame = ttk.Frame(header_frame)
        logo_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(logo_frame, text="🚀", font=('Arial', 24)).pack(side=tk.LEFT, padx=10)
        
        title_frame = ttk.Frame(logo_frame)
        title_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Label(title_frame, text="СИСТЕМА УПРАВЛЕНИЯ ПРОЕКТАМИ", 
                 font=('Arial', 18, 'bold'), foreground='#2c3e50').pack(anchor=tk.W)
        ttk.Label(title_frame, text="Информационная поддержка процесса проектирования", 
                 font=('Arial', 12), foreground='#7f8c8d').pack(anchor=tk.W)
    
    def create_login_section(self):
        login_frame = ttk.LabelFrame(self.main_frame, text="Вход в систему")
        login_frame.pack(fill=tk.X, pady=10)
        
        input_frame = ttk.Frame(login_frame)
        input_frame.pack(fill=tk.X, padx=15, pady=15)
        
        ttk.Label(input_frame, text="Логин:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.username_entry = ttk.Entry(input_frame, width=30, font=('Arial', 10))
        self.username_entry.grid(row=0, column=1, sticky=tk.W, pady=5, padx=10)
        
        ttk.Label(input_frame, text="Пароль:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.password_entry = ttk.Entry(input_frame, width=30, show="*", font=('Arial', 10))
        self.password_entry.grid(row=1, column=1, sticky=tk.W, pady=5, padx=10)
        
        btn_frame = ttk.Frame(login_frame)
        btn_frame.pack(fill=tk.X, padx=15, pady=10)
        
        ttk.Button(btn_frame, text="Войти", command=self.login).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Очистить", command=self.clear_login).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Выход", command=self.exit_app).pack(side=tk.RIGHT, padx=5)
        
        self.root.bind('<Return>', lambda e: self.login())
        self.username_entry.focus()
    
    def create_info_section(self):
        info_frame = ttk.LabelFrame(self.main_frame, text="Информация о системе")
        info_frame.pack(fill=tk.X, pady=10)
        
        stats_frame = ttk.Frame(info_frame)
        stats_frame.pack(fill=tk.X, padx=15, pady=10)
        
        try:
            data = load_data()
            
            ttk.Label(stats_frame, text="📂 Проекты:", font=('Arial', 10, 'bold')).grid(row=0, column=0, sticky=tk.W)
            ttk.Label(stats_frame, text=f"{len(data['projects'])}", font=('Arial', 10)).grid(row=0, column=1, sticky=tk.W, padx=10)
            
            ttk.Label(stats_frame, text="📝 Задачи:", font=('Arial', 10, 'bold')).grid(row=0, column=2, sticky=tk.W, padx=20)
            ttk.Label(stats_frame, text=f"{len(data.get('tasks', []))}", font=('Arial', 10)).grid(row=0, column=3, sticky=tk.W, padx=10)
            
            ttk.Label(stats_frame, text="👥 Пользователи:", font=('Arial', 10, 'bold')).grid(row=1, column=0, sticky=tk.W, pady=5)
            ttk.Label(stats_frame, text=f"{len(data['users'])}", font=('Arial', 10)).grid(row=1, column=1, sticky=tk.W, padx=10)
            
            ttk.Label(stats_frame, text="🔨 Работы:", font=('Arial', 10, 'bold')).grid(row=1, column=2, sticky=tk.W, padx=20, pady=5)
            ttk.Label(stats_frame, text=f"{len(data.get('works', []))}", font=('Arial', 10)).grid(row=1, column=3, sticky=tk.W, padx=10)
            
        except Exception as e:
            ttk.Label(stats_frame, text="Ошибка загрузки данных", foreground='red').pack()
    
    def create_status_bar(self):
        status_frame = ttk.Frame(self.main_frame)
        status_frame.pack(fill=tk.X, pady=5)
        
        self.status_label = ttk.Label(status_frame, text="Готов к работе. Введите учетные данные для входа.")
        self.status_label.pack(side=tk.LEFT)
    
    def login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showwarning("Предупреждение", "Введите логин и пароль")
            self.status_label.config(text="Ошибка: Введите логин и пароль")
            return
        
        self.status_label.config(text="Выполняется вход...")
        self.root.update()
        
        try:
            user = login(username, password)
            
            if user:
                self.user = user
                self.status_label.config(text=f"Успешный вход! Добро пожаловать, {user['full_name']}")
                messagebox.showinfo("Успех", f"Добро пожаловать, {user['full_name']}!")
                self.launch_main_app()
            else:
                self.status_label.config(text="Ошибка входа: неверный логин или пароль")
                messagebox.showerror("Ошибка", "Неверный логин или пароль")
                
        except Exception as e:
            self.status_label.config(text=f"Ошибка входа: {str(e)}")
            messagebox.showerror("Ошибка", f"Ошибка при входе: {str(e)}")
    
    def clear_login(self):
        self.username_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)
        self.username_entry.focus()
        self.status_label.config(text="Поля очищены. Готов к работе.")
    
    def exit_app(self):
        if messagebox.askyesno("Подтверждение", "Вы уверены, что хотите выйти?"):
            self.root.quit()
    
    def launch_main_app(self):
        try:
            self.root.withdraw()
            
            main_root = tk.Toplevel(self.root)
            main_root.title(f"Система управления проектами - {self.user['full_name']}")
            main_root.geometry("1200x800")
            
            self.center_specific_window(main_root, 1200, 800)
            
            app = ProjectManagementApp(main_root, self.user)
            
            def on_main_close():
                if messagebox.askyesno("Подтверждение", "Вы уверены, что хотите выйти из системы?"):
                    main_root.destroy()
                    self.root.deiconify()
                    self.clear_login()
            
            main_root.protocol("WM_DELETE_WINDOW", on_main_close)
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось запустить главное приложение: {e}")
            self.root.deiconify()
    
    def center_specific_window(self, window, width, height):
        window.update_idletasks()
        x = (window.winfo_screenwidth() // 2) - (width // 2)
        y = (window.winfo_screenheight() // 2) - (height // 2)
        window.geometry(f'{width}x{height}+{x}+{y}')

def main():
    """Главная функция запуска приложения"""
    root = tk.Tk()
    app = StartMenu(root)
    root.mainloop()

if __name__ == "__main__":
    main()