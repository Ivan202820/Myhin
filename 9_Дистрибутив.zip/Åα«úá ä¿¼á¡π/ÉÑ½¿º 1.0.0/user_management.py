from database import load_data, save_data, AVAILABLE_PERMISSIONS, get_default_permissions
from auth import ROLES

def user_management_menu(current_user):
    """Меню управления пользователями для администратора"""
    while True:
        print("\n=== Управление пользователями ===")
        print("1. Список пользователей")
        print("2. Создать пользователя")
        print("0. Назад")
        
        choice = input("Выберите опцию: ")
        
        if choice == "0":
            break
        elif choice == "1":
            list_users_detailed(current_user)
        elif choice == "2":
            create_user(current_user)
        else:
            print("❌ Неверный выбор")
        
        input("\nНажмите Enter для продолжения...")

def list_users_detailed(current_user):
    data = load_data()
    print("\n" + "="*50)
    print("СПИСОК ПОЛЬЗОВАТЕЛЕЙ")
    print("="*50)
    
    for user in data["users"]:
        print(f"\n👤 {user['username']} - {user.get('full_name', 'N/A')}")
        print(f"   Роль: {ROLES.get(user['role'], user['role'])}")
        print("   Права доступа:")
        
        permissions = user.get('permissions', {})
        for perm_key, perm_name in AVAILABLE_PERMISSIONS.items():
            status = "✅ ВКЛ" if permissions.get(perm_key, False) else "❌ ВЫКЛ"
            print(f"     {perm_name}: {status}")
        
        print("-" * 30)

def create_user(current_user):
    from auth import create_user as auth_create_user
    auth_create_user(current_user)