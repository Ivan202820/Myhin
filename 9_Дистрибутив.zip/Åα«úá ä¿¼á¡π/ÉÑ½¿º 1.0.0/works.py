from database import load_data, save_data, WORK_STATUSES

def can_edit_work(work, user):
    """Проверяет можно ли редактировать работу"""
    if user["permissions"].get("force_edit", False):
        return True
    
    # Получаем задачу и проект
    data = load_data()
    task = next((t for t in data["tasks"] if t["id"] == work["task_id"]), None)
    
    if task:
        project = next((p for p in data["projects"] if p["id"] == task["project_id"]), None)
        # Если проект закрыт, нельзя редактировать работу
        if project and project["status"] in ["выполнено", "не_выполнено"]:
            return False
    
    return work["status"] in ["черновик", "на_рассмотрении"]


def show_work_details(work, data=None):
    """Показывает детали работы (для CLI)"""
    if data is None:
        from database import load_data
        data = load_data()
    
    # Находим задачу
    task = next((t for t in data.get("tasks", []) if t["id"] == work.get("task_id")), None)
    task_title = task.get("title", "Неизвестно") if task else "Неизвестно"
    
    print("\n=== ДЕТАЛИ РАБОТЫ ===")
    print(f"ID: {work.get('id', '')}")
    print(f"Название: {work.get('title', '')}")
    print(f"Статус: {work.get('status', 'черновик')}")
    print(f"Задача: {task_title}")
    print(f"Описание: {work.get('description', '')}")
    print(f"Исполнитель: {work.get('executor', '')}")
    print(f"Создатель: {work.get('created_by', '')}")

def complete_work(work_id, user):
    """Отмечает работу как выполненную (для исполнителя)"""
    data = load_data()
    work = next((w for w in data["works"] if w["id"] == work_id), None)
    
    if not work:
        print("❌ Работа не найдена")
        return
    
    # Проверяем что пользователь является исполнителем
    if work["executor"] != user["username"] and not user["permissions"].get("force_edit", False):
        print("❌ Вы не являетесь исполнителем этой работы")
        return
    
    work["status"] = "выполнено"
    save_data(data)
    print("✅ Работа отмечена как выполненная!")
    
    # Проверяем можно ли закрыть задачу
    check_task_completion(work["task_id"])

def check_task_completion(task_id):
    """Проверяет можно ли закрыть задачу (все работы завершены)"""
    data = load_data()
    task_works = [w for w in data.get("works", []) if w["task_id"] == task_id]
    
    if all(work["status"] in ["выполнено", "не_выполнено"] for work in task_works):
        task = next((t for t in data["tasks"] if t["id"] == task_id), None)
        if task and task["status"] not in ["выполнено", "не_выполнено"]:
            print(f"⚠️ Все работы задачи '{task['title']}' завершены. Задачу можно закрыть.")