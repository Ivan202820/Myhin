import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta
from database import load_data, save_data
import threading
import time

class NotificationSystem:
    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.notification_window = None
        
    def create_personalized_notifications(self):
        """Создает персонализированные уведомления для пользователя"""
        data = load_data()
        notifications_created = 0
        
        # Проверяем просроченные задачи, где пользователь является ответственным
        overdue_tasks = self.get_overdue_tasks(data)
        for task in overdue_tasks:
            if task.get("responsible") == self.user["username"]:
                self.create_notification(
                    self.user["username"],
                    "Просроченная задача",
                    f"Задача '{task.get('title')}' просрочена. Срок: {task.get('deadline')}"
                )
                notifications_created += 1
        
        # Проверяем работы, где пользователь является исполнителем
        if self.user["role"] == "исполнитель":
            user_works = [w for w in data.get("works", []) 
                         if w.get("executor") == self.user["username"] and 
                         w.get("status") not in ["выполнено", "не_выполнено"]]
            
            for work in user_works:
                # Находим задачу
                task = next((t for t in data.get("tasks", []) if t["id"] == work.get("task_id")), None)
                if task and task.get("deadline"):
                    try:
                        deadline = datetime.strptime(task["deadline"], '%Y-%m-%d').date()
                        days_until_deadline = (deadline - datetime.now().date()).days
                        if 0 <= days_until_deadline <= 3:
                            self.create_notification(
                                self.user["username"],
                                "Скоро срок",
                                f"Работа '{work.get('title')}' должна быть завершена через {days_until_deadline} дней"
                            )
                            notifications_created += 1
                    except ValueError:
                        continue
        
        return notifications_created
    
    def create_notification(self, username, notification_type, message):
        """Создает новое уведомление"""
        data = load_data()
        
        notification = {
            "id": len(data.get("notifications", [])) + 1,
            "user": username,
            "type": notification_type,
            "message": message,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "read": False
        }
        
        if "notifications" not in data:
            data["notifications"] = []
        
        # Проверяем, нет ли уже такого уведомления
        existing = [n for n in data["notifications"] 
                   if n.get("user") == username and n.get("message") == message and not n.get("read")]
        if not existing:
            data["notifications"].append(notification)
            save_data(data)
            return True
        return False
    
    def get_overdue_tasks(self, data):
        """Возвращает просроченные задачи"""
        today = datetime.now().date()
        overdue = []
        
        for task in data.get("tasks", []):
            if task.get("deadline") and task.get("status") not in ["выполнено", "не_выполнено"]:
                try:
                    deadline = datetime.strptime(task["deadline"], "%Y-%m-%d").date()
                    if deadline < today:
                        overdue.append(task)
                except ValueError:
                    continue
        
        return overdue
    
    def get_tasks_due_today(self, data):
        """Возвращает задачи, срок которых истекает сегодня"""
        today = datetime.now().date()
        due_today = []
        
        for task in data.get("tasks", []):
            if task.get("deadline") and task.get("status") not in ["выполнено", "не_выполнено"]:
                try:
                    deadline = datetime.strptime(task["deadline"], "%Y-%m-%d").date()
                    if deadline == today:
                        due_today.append(task)
                except ValueError:
                    continue
        
        return due_today
    
    def get_projects_without_tasks(self, data):
        """Возвращает проекты без задач"""
        empty_projects = []
        
        for project in data["projects"]:
            project_tasks = [t for t in data.get("tasks", []) if t.get("project_id") == project["id"]]
            if not project_tasks and project["status"] not in ["выполнено", "не_выполнено"]:
                empty_projects.append(project)
        
        return empty_projects

def show_immediate_notification(root, title, message):
    """Показывает немедленное уведомление"""
    messagebox.showwarning(title, message, parent=root)