# start_menu.py (обновленная версия)
import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os
import threading

# Добавляем текущую директорию в путь для импортов
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class StartMenu:
    def __init__(self, root):
        self.root = root
        self.user = None
        self.setup_menu()
    
    def setup_menu(self):
        self.root.title("Система управления проектами - Стартовое меню")
        self.root.geometry("800x600")
        self.root.configure(bg='#f0f0f0')
        
        # Центрируем окно
        self.center_window()
        
        # Создаем стиль для красивого интерфейса
        self.setup_styles()
        
        # Инициализируем синхронизацию в фоновом режиме
        self.init_sync_in_background()
        
        # Главный фрейм
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Заголовок
        self.create_header()
        
        # Панель входа
        self.create_login_section()
        
        # Информационная панель
        self.create_info_section()
        
        # Панель синхронизации БД
        self.create_sync_section()
        
        # Статус бар
        self.create_status_bar()
    
    def init_sync_in_background(self):
        """Инициализация синхронизации в фоновом потоке"""
        def sync_thread():
            try:
                from db_sync_manager import check_and_sync_on_startup
                check_and_sync_on_startup()
            except Exception as e:
                print(f"Ошибка инициализации синхронизации: {e}")
        
        # Запускаем в отдельном потоке, чтобы не блокировать UI
        thread = threading.Thread(target=sync_thread, daemon=True)
        thread.start()
    
    def center_window(self):
        """Центрирует окно на экране"""
        self.root.update_idletasks()
        width = 800
        height = 600
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def setup_styles(self):
        """Настраивает стили интерфейса"""
        style = ttk.Style()
        style.configure('Title.TLabel', font=('Arial', 18, 'bold'), foreground='#2c3e50')
        style.configure('Subtitle.TLabel', font=('Arial', 12), foreground='#7f8c8d')
        style.configure('SyncGreen.TLabel', font=('Arial', 9, 'bold'), foreground='#27ae60')
        style.configure('SyncRed.TLabel', font=('Arial', 9, 'bold'), foreground='#e74c3c')
    
    def create_header(self):
        """Создает заголовок приложения"""
        header_frame = ttk.Frame(self.main_frame)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Логотип и название
        logo_frame = ttk.Frame(header_frame)
        logo_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(logo_frame, text="🚀", font=('Arial', 24)).pack(side=tk.LEFT, padx=10)
        
        title_frame = ttk.Frame(logo_frame)
        title_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Label(title_frame, text="СИСТЕМА УПРАВЛЕНИЯ ПРОЕКТАМИ", 
                 style='Title.TLabel').pack(anchor=tk.W)
        ttk.Label(title_frame, text="Информационная поддержка процесса проектирования", 
                 style='Subtitle.TLabel').pack(anchor=tk.W)
    
    def create_login_section(self):
        """Создает секцию входа в систему"""
        login_frame = ttk.LabelFrame(self.main_frame, text="Вход в систему")
        login_frame.pack(fill=tk.X, pady=10)
        
        # Поля ввода
        input_frame = ttk.Frame(login_frame)
        input_frame.pack(fill=tk.X, padx=15, pady=15)
        
        ttk.Label(input_frame, text="Логин:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.username_entry = ttk.Entry(input_frame, width=30, font=('Arial', 10))
        self.username_entry.grid(row=0, column=1, sticky=tk.W, pady=5, padx=10)
        
        ttk.Label(input_frame, text="Пароль:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.password_entry = ttk.Entry(input_frame, width=30, show="*", font=('Arial', 10))
        self.password_entry.grid(row=1, column=1, sticky=tk.W, pady=5, padx=10)
        
        # Кнопки входа
        btn_frame = ttk.Frame(login_frame)
        btn_frame.pack(fill=tk.X, padx=15, pady=10)
        
        ttk.Button(btn_frame, text="Войти", command=self.login).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Очистить", command=self.clear_login).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Выход", command=self.exit_app).pack(side=tk.RIGHT, padx=5)
        
        # Бинд Enter для быстрого входа
        self.root.bind('<Return>', lambda e: self.login())
        
        # Установка фокуса на поле логина
        self.username_entry.focus()
    
    def create_info_section(self):
        """Создает информационную секцию"""
        info_frame = ttk.LabelFrame(self.main_frame, text="Информация о системе")
        info_frame.pack(fill=tk.X, pady=10)
        
        # Статистика системы
        stats_frame = ttk.Frame(info_frame)
        stats_frame.pack(fill=tk.X, padx=15, pady=10)
        
        try:
            from database import load_data
            data = load_data()
            
            # Проверяем структуру данных
            if not isinstance(data, dict):
                raise ValueError("Некорректная структура данных")
            
            # Проекты
            ttk.Label(stats_frame, text="📂 Проекты:", font=('Arial', 10, 'bold')).grid(row=0, column=0, sticky=tk.W)
            ttk.Label(stats_frame, text=f"{len(data.get('projects', []))}", font=('Arial', 10)).grid(row=0, column=1, sticky=tk.W, padx=10)
            
            # Задачи
            ttk.Label(stats_frame, text="📝 Задачи:", font=('Arial', 10, 'bold')).grid(row=0, column=2, sticky=tk.W, padx=20)
            ttk.Label(stats_frame, text=f"{len(data.get('tasks', []))}", font=('Arial', 10)).grid(row=0, column=3, sticky=tk.W, padx=10)
            
            # Пользователи
            ttk.Label(stats_frame, text="👥 Пользователи:", font=('Arial', 10, 'bold')).grid(row=1, column=0, sticky=tk.W, pady=5)
            ttk.Label(stats_frame, text=f"{len(data.get('users', []))}", font=('Arial', 10)).grid(row=1, column=1, sticky=tk.W, padx=10)
            
            # Работы
            ttk.Label(stats_frame, text="🔨 Работы:", font=('Arial', 10, 'bold')).grid(row=1, column=2, sticky=tk.W, padx=20, pady=5)
            ttk.Label(stats_frame, text=f"{len(data.get('works', []))}", font=('Arial', 10)).grid(row=1, column=3, sticky=tk.W, padx=10)
            
        except Exception as e:
            print(f"Ошибка загрузки данных для статистики: {e}")
            ttk.Label(stats_frame, text="Статистика недоступна", foreground='red').pack()
    
    def create_sync_section(self):
        """Создает секцию синхронизации БД"""
        sync_frame = ttk.LabelFrame(self.main_frame, text="Синхронизация с базой данных")
        sync_frame.pack(fill=tk.X, pady=10)
        
        # Информация о синхронизации
        self.sync_info_frame = ttk.Frame(sync_frame)
        self.sync_info_frame.pack(fill=tk.X, padx=15, pady=10)
        
        # Кнопки управления синхронизацией
        btn_frame = ttk.Frame(sync_frame)
        btn_frame.pack(fill=tk.X, padx=15, pady=10)
        
        ttk.Button(btn_frame, text="🔄 Синхронизировать сейчас", 
                  command=self.manual_sync).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="📊 Статус синхронизации", 
                  command=self.show_sync_status).pack(side=tk.LEFT, padx=5)
        
        # Обновляем информацию о синхронизации
        self.update_sync_info()
    
    def update_sync_info(self):
        """Обновляет информацию о синхронизации"""
        for widget in self.sync_info_frame.winfo_children():
            widget.destroy()
        
        try:
            from db_sync_manager import get_sync_status
            status = get_sync_status()
            
            row = 0
            
            # Статус PostgreSQL
            if status['postgres_available']:
                ttk.Label(self.sync_info_frame, text="✅ PostgreSQL: подключено", 
                         style='SyncGreen.TLabel').grid(row=row, column=0, sticky=tk.W, pady=2)
            else:
                ttk.Label(self.sync_info_frame, text="❌ PostgreSQL: не подключено", 
                         style='SyncRed.TLabel').grid(row=row, column=0, sticky=tk.W, pady=2)
            
            row += 1
            
            # Время последней синхронизации
            if status['last_sync_time']:
                last_sync = status['last_sync_time'].strftime("%Y-%m-%d %H:%M:%S")
                ttk.Label(self.sync_info_frame, 
                         text=f"📅 Последняя синхронизация: {last_sync}").grid(
                         row=row, column=0, sticky=tk.W, pady=2)
            else:
                ttk.Label(self.sync_info_frame, 
                         text="📅 Последняя синхронизация: не выполнялась").grid(
                         row=row, column=0, sticky=tk.W, pady=2)
            
            row += 1
            
            # Интервал синхронизации
            minutes = status['sync_interval'] // 60
            ttk.Label(self.sync_info_frame, 
                     text=f"⏱️  Автосинхронизация: каждые {minutes} минут").grid(
                     row=row, column=0, sticky=tk.W, pady=2)
            
        except Exception as e:
            ttk.Label(self.sync_info_frame, 
                     text="⚠️  Информация о синхронизации недоступна").grid(
                     row=0, column=0, sticky=tk.W)
    
    def create_status_bar(self):
        """Создает статус бар"""
        status_frame = ttk.Frame(self.main_frame)
        status_frame.pack(fill=tk.X, pady=5)
        
        self.status_label = ttk.Label(status_frame, text="Готов к работе. Введите учетные данные для входа.")
        self.status_label.pack(side=tk.LEFT)
        
        # Кнопка обновления синхронизации
        ttk.Button(status_frame, text="🔄 Обновить", 
                  command=self.update_sync_info, width=10).pack(side=tk.RIGHT)
    
    def login(self):
        """Обрабатывает вход в систему"""
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showwarning("Предупреждение", "Введите логин и пароль")
            self.status_label.config(text="Ошибка: Введите логин и пароль")
            return
        
        self.status_label.config(text="Выполняется вход...")
        self.root.update()
        
        try:
            # Импортируем здесь, чтобы избежать циклических импортов
            from auth import login
            # Выполняем вход
            user = login(username, password)
            
            if user:
                self.user = user
                self.status_label.config(text=f"Успешный вход! Добро пожаловать, {user['full_name']}")
                messagebox.showinfo("Успех", f"Добро пожаловать, {user['full_name']}!")
                
                # Запускаем главное приложение
                self.launch_main_app()
            else:
                self.status_label.config(text="Ошибка входа: неверный логин или пароль")
                messagebox.showerror("Ошибка", "Неверный логин или пароль")
                
        except Exception as e:
            self.status_label.config(text=f"Ошибка входа: {str(e)}")
            messagebox.showerror("Ошибка", f"Ошибка при входе: {str(e)}")
    
    def clear_login(self):
        """Очищает поля ввода"""
        self.username_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)
        self.username_entry.focus()
        self.status_label.config(text="Поля очищены. Готов к работе.")
    
    def exit_app(self):
        """Выход из приложения"""
        try:
            # Останавливаем синхронизацию перед выходом
            from db_sync_manager import sync_manager
            sync_manager.stop_auto_sync()
        except:
            pass
        
        if messagebox.askyesno("Подтверждение", "Вы уверены, что хотите выйти?"):
            self.root.quit()
    
    def manual_sync(self):
        """Ручная синхронизация"""
        self.status_label.config(text="Выполняется ручная синхронизация...")
        self.root.update()
        
        try:
            from db_sync_manager import sync_manager
            
            # Выполняем синхронизацию в фоновом потоке
            def sync_thread():
                sync_manager.manual_sync('both')
                self.root.after(0, lambda: self.sync_complete())
            
            thread = threading.Thread(target=sync_thread, daemon=True)
            thread.start()
            
        except Exception as e:
            self.status_label.config(text=f"Ошибка синхронизации: {str(e)}")
            messagebox.showerror("Ошибка", f"Ошибка синхронизации: {e}")
    
    def sync_complete(self):
        """Вызывается после завершения синхронизации"""
        self.status_label.config(text="Синхронизация завершена")
        self.update_sync_info()
        messagebox.showinfo("Синхронизация", "Синхронизация с базой данных завершена успешно!")
    
    def show_sync_status(self):
        """Показывает детальный статус синхронизации"""
        try:
            from db_sync_manager import get_sync_status
            status = get_sync_status()
            
            status_text = "=== СТАТУС СИНХРОНИЗАЦИИ ===\n\n"
            
            if status['postgres_available']:
                status_text += "✅ PostgreSQL: подключено\n"
            else:
                status_text += "❌ PostgreSQL: не подключено\n"
                status_text += "   Проверьте:\n"
                status_text += "   1. Запущен ли PostgreSQL\n"
                status_text += "   2. Правильность настроек подключения\n"
                status_text += "   3. Наличие базы данных project_management_db\n"
            
            if status['last_sync_time']:
                last_sync = status['last_sync_time'].strftime("%Y-%m-%d %H:%M:%S")
                status_text += f"\n📅 Последняя синхронизация: {last_sync}\n"
            else:
                status_text += "\n📅 Последняя синхронизация: не выполнялась\n"
            
            if status['is_syncing']:
                status_text += "\n🔄 Синхронизация выполняется...\n"
            
            minutes = status['sync_interval'] // 60
            status_text += f"\n⏱️  Автосинхронизация: каждые {minutes} минут\n"
            
            messagebox.showinfo("Статус синхронизации", status_text)
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось получить статус синхронизации: {e}")
    
    def launch_main_app(self):
        """Запускает главное приложение"""
        try:
            from gui import ProjectManagementApp
            
            # Закрываем стартовое меню
            self.root.withdraw()
            
            # Создаем главное окно приложения
            main_root = tk.Toplevel(self.root)
            main_root.title(f"Система управления проектами - {self.user['full_name']}")
            main_root.geometry("1200x800")
            
            # Центрируем главное окно
            self.center_specific_window(main_root, 1200, 800)
            
            # Запускаем главное приложение
            app = ProjectManagementApp(main_root, self.user)
            
            # Обработка закрытия главного окна
            def on_main_close():
                if messagebox.askyesno("Подтверждение", "Вы уверены, что хотите выйти из системы?"):
                    main_root.destroy()
                    self.root.deiconify()  # Показываем стартовое меню снова
                    self.clear_login()
            
            main_root.protocol("WM_DELETE_WINDOW", on_main_close)
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось запустить главное приложение: {e}")
            self.root.deiconify()
    
    def center_specific_window(self, window, width, height):
        """Центрирует конкретное окно"""
        window.update_idletasks()
        x = (window.winfo_screenwidth() // 2) - (width // 2)
        y = (window.winfo_screenheight() // 2) - (height // 2)
        window.geometry(f'{width}x{height}+{x}+{y}')

def main():
    """Главная функция запуска приложения"""
    root = tk.Tk()
    app = StartMenu(root)
    root.mainloop()

if __name__ == "__main__":
    main()