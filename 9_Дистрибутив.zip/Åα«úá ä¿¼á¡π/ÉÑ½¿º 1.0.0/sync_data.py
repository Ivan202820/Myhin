import psycopg2
import json
import os
from datetime import datetime
import sys
# ручная синхронизация с БД
# Конфигурация подключения к PostgreSQL
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "project_management_db",
    "user": "postgres",
    "password": "0"  # Пароль, который вы задали при установке PostgreSQL
}

def load_json_data(file_path):
    """Загрузка данных из JSON файла"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Ошибка загрузки JSON файла: {e}")
        return None

def connect_db():
    """Подключение к базе данных"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        print(f"Ошибка подключения к БД: {e}")
        return None

def clear_table(conn, table_name):
    """Очистка таблицы"""
    try:
        cur = conn.cursor()
        cur.execute(f"DELETE FROM {table_name};")
        conn.commit()
        print(f"Таблица {table_name} очищена")
    except Exception as e:
        print(f"Ошибка очистки таблицы {table_name}: {e}")
        conn.rollback()

def sync_users(conn, users_data):
    """Синхронизация пользователей"""
    cur = conn.cursor()
    
    for user in users_data:
        try:
            # Проверяем наличие поля is_active
            is_active = user.get('is_active', True)
            
            cur.execute("""
                INSERT INTO users (username, password, role, full_name, permissions, is_active)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (username) DO UPDATE SET
                    password = EXCLUDED.password,
                    role = EXCLUDED.role,
                    full_name = EXCLUDED.full_name,
                    permissions = EXCLUDED.permissions,
                    is_active = EXCLUDED.is_active,
                    updated_at = CURRENT_TIMESTAMP
            """, (
                user['username'],
                user['password'],
                user['role'],
                user['full_name'],
                json.dumps(user['permissions'], ensure_ascii=False),
                is_active
            ))
        except Exception as e:
            print(f"Ошибка вставки пользователя {user['username']}: {e}")
            conn.rollback()
            return False
    
    conn.commit()
    print(f"Пользователи синхронизированы: {len(users_data)} записей")
    return True

def sync_projects(conn, projects_data):
    """Синхронизация проектов"""
    cur = conn.cursor()
    
    for project in projects_data:
        try:
            # Преобразуем даты (пустые строки в NULL)
            actual_end = project['actual_end'] if project['actual_end'] else None
            
            cur.execute("""
                INSERT INTO projects (id, name, client, start_date, planned_end, actual_end, 
                                     manager, cost, status, custom_fields, attachments)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    name = EXCLUDED.name,
                    client = EXCLUDED.client,
                    start_date = EXCLUDED.start_date,
                    planned_end = EXCLUDED.planned_end,
                    actual_end = EXCLUDED.actual_end,
                    manager = EXCLUDED.manager,
                    cost = EXCLUDED.cost,
                    status = EXCLUDED.status,
                    custom_fields = EXCLUDED.custom_fields,
                    attachments = EXCLUDED.attachments,
                    updated_at = CURRENT_TIMESTAMP
            """, (
                project['id'],
                project['name'],
                project['client'],
                project['start_date'],
                project['planned_end'],
                actual_end,
                project['manager'],
                project['cost'],
                project['status'],
                json.dumps(project['custom_fields'], ensure_ascii=False),
                json.dumps(project['attachments'], ensure_ascii=False)
            ))
        except Exception as e:
            print(f"Ошибка вставки проекта {project['id']}: {e}")
            conn.rollback()
            return False
    
    conn.commit()
    print(f"Проекты синхронизированы: {len(projects_data)} записей")
    return True

def sync_tasks(conn, tasks_data):
    """Синхронизация задач"""
    cur = conn.cursor()
    
    for task in tasks_data:
        try:
            cur.execute("""
                INSERT INTO tasks (id, project_id, title, description, deadline, priority, 
                                  responsible, status, custom_fields, materials, attachments)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    project_id = EXCLUDED.project_id,
                    title = EXCLUDED.title,
                    description = EXCLUDED.description,
                    deadline = EXCLUDED.deadline,
                    priority = EXCLUDED.priority,
                    responsible = EXCLUDED.responsible,
                    status = EXCLUDED.status,
                    custom_fields = EXCLUDED.custom_fields,
                    materials = EXCLUDED.materials,
                    attachments = EXCLUDED.attachments,
                    updated_at = CURRENT_TIMESTAMP
            """, (
                task['id'],
                task['project_id'],
                task['title'],
                task['description'],
                task['deadline'],
                task['priority'],
                task['responsible'],
                task['status'],
                json.dumps(task['custom_fields'], ensure_ascii=False),
                json.dumps(task['materials'], ensure_ascii=False),
                json.dumps(task['attachments'], ensure_ascii=False)
            ))
        except Exception as e:
            print(f"Ошибка вставки задачи {task['id']}: {e}")
            conn.rollback()
            return False
    
    conn.commit()
    print(f"Задачи синхронизированы: {len(tasks_data)} записей")
    return True

def sync_works(conn, works_data):
    """Синхронизация работ"""
    cur = conn.cursor()
    
    for work in works_data:
        try:
            cur.execute("""
                INSERT INTO works (id, task_id, title, description, parameters, 
                                  executor, status, created_by, attachments)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    task_id = EXCLUDED.task_id,
                    title = EXCLUDED.title,
                    description = EXCLUDED.description,
                    parameters = EXCLUDED.parameters,
                    executor = EXCLUDED.executor,
                    status = EXCLUDED.status,
                    created_by = EXCLUDED.created_by,
                    attachments = EXCLUDED.attachments,
                    updated_at = CURRENT_TIMESTAMP
            """, (
                work['id'],
                work['task_id'],
                work['title'],
                work['description'],
                work['parameters'],
                work['executor'],
                work['status'],
                work['created_by'],
                json.dumps(work['attachments'], ensure_ascii=False)
            ))
        except Exception as e:
            print(f"Ошибка вставки работы {work['id']}: {e}")
            conn.rollback()
            return False
    
    conn.commit()
    print(f"Работы синхронизированы: {len(works_data)} записей")
    return True

def sync_notifications(conn, notifications_data):
    """Синхронизация уведомлений"""
    cur = conn.cursor()
    
    for notification in notifications_data:
        try:
            cur.execute("""
                INSERT INTO notifications (id, user_username, type, message, date, is_read)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    user_username = EXCLUDED.user_username,
                    type = EXCLUDED.type,
                    message = EXCLUDED.message,
                    date = EXCLUDED.date,
                    is_read = EXCLUDED.is_read
            """, (
                notification['id'],
                notification['user'],
                notification['type'],
                notification['message'],
                notification['date'],
                notification['read']
            ))
        except Exception as e:
            print(f"Ошибка вставки уведомления {notification['id']}: {e}")
            conn.rollback()
            return False
    
    conn.commit()
    print(f"Уведомления синхронизированы: {len(notifications_data)} записей")
    return True

def main():
    """Основная функция синхронизации"""
    # Укажите путь к вашему JSON файлу
    json_file = "data.json"  # Поместите файл в ту же папку, что и скрипт
    
    print("=== Начало синхронизации ===")
    
    # Загружаем данные из JSON
    data = load_json_data(json_file)
    if not data:
        print("Не удалось загрузить данные из JSON")
        sys.exit(1)
    
    # Подключаемся к БД
    conn = connect_db()
    if not conn:
        print("Не удалось подключиться к базе данных")
        sys.exit(1)
    
    try:
        # Синхронизируем в правильном порядке (с учетом внешних ключей)
        print("\n1. Синхронизация пользователей...")
        if not sync_users(conn, data.get('users', [])):
            raise Exception("Ошибка синхронизации пользователей")
        
        print("\n2. Синхронизация проектов...")
        if not sync_projects(conn, data.get('projects', [])):
            raise Exception("Ошибка синхронизации проектов")
        
        print("\n3. Синхронизация задач...")
        if not sync_tasks(conn, data.get('tasks', [])):
            raise Exception("Ошибка синхронизации задач")
        
        print("\n4. Синхронизация работ...")
        if not sync_works(conn, data.get('works', [])):
            raise Exception("Ошибка синхронизации работ")
        
        print("\n5. Синхронизация уведомлений...")
        if not sync_notifications(conn, data.get('notifications', [])):
            raise Exception("Ошибка синхронизации уведомлений")
        
        print("\n=== Синхронизация успешно завершена ===")
        print(f"Всего синхронизировано:")
        print(f"  - Пользователей: {len(data.get('users', []))}")
        print(f"  - Проектов: {len(data.get('projects', []))}")
        print(f"  - Задач: {len(data.get('tasks', []))}")
        print(f"  - Работ: {len(data.get('works', []))}")
        print(f"  - Уведомлений: {len(data.get('notifications', []))}")
        
    except Exception as e:
        print(f"\n!!! Ошибка в процессе синхронизации: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    main()
