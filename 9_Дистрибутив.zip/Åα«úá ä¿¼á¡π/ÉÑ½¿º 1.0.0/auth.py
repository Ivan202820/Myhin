import hashlib
import os
import json
from datetime import datetime

# Роли пользователей
ROLES = {
    "администратор": "Администратор системы",
    "руководитель_проекта": "Руководитель проекта", 
    "ответственный_исполнитель": "Ответственный исполнитель",
    "исполнитель": "Исполнитель"
}

def hash_password(password):
    """Хеширует пароль с солью"""
    salt = os.urandom(32).hex()
    password_hash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    ).hex()
    return f"{salt}${password_hash}"

def verify_password(password, hashed_password):
    """Проверяет пароль против хеша"""
    if not hashed_password or '$' not in hashed_password:
        return False
    
    try:
        salt, stored_hash = hashed_password.split('$')
        new_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        ).hex()
        return new_hash == stored_hash
    except:
        return False

def migrate_passwords():
    """Мигрирует пароли из старого формата в новый (с солью)"""
    from database import load_data, save_data
    
    data = load_data()
    migrated = False
    
    for user in data["users"]:
        current_password = user.get("password", "")
        
        # Если пароль уже в новом формате (содержит $), пропускаем
        if '$' in current_password:
            continue
            
        # Если пароль в старом формате, хешируем его
        if current_password:
            user["password"] = hash_password(current_password)
            migrated = True
    
    if migrated:
        save_data(data)
        print("✅ Пароли мигрированы в новый безопасный формат")

def log_security_event(event_type, username, description):
    """Логирует события безопасности"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"{timestamp} - {event_type} - Пользователь: {username} - {description}\n"
    
    with open("security.log", "a", encoding="utf-8") as f:
        f.write(log_entry)

def load_data():
    """Загружает данные из JSON файла"""
    try:
        with open("data.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        # Если файла нет, создаем начальные данные
        from database import create_initial_data
        return create_initial_data()

def migrate_user_data(user):
    """Мигрирует данные пользователя к новой структуре"""
    from database import get_default_permissions
    
    if "permissions" not in user:
        user["permissions"] = get_default_permissions(user.get("role", "исполнитель"))
    
    if "full_name" not in user:
        user["full_name"] = user.get("username", "Неизвестный пользователь")
    
    if "is_active" not in user:
        user["is_active"] = True
    
    return user

def login(username_input=None, password_input=None):
    """Функция входа в систему с поддержкой GUI и CLI"""
    # Мигрируем пароли при первом запуске
    migrate_passwords()
    
    data = load_data()
    
    # Если параметры не переданы, используем input (CLI режим)
    if username_input is None or password_input is None:
        print("\n=== Вход в систему ===")
        username = input("Логин: ")
        password = input("Пароль: ")
    else:
        username = username_input
        password = password_input
    
    for user in data["users"]:
        if (user["username"] == username and 
            verify_password(password, user["password"]) and
            user.get("is_active", True)):
            # Мигрируем данные пользователя если нужно
            user = migrate_user_data(user)
            # Добавляем описание роли на русском
            user["role_display"] = ROLES.get(user["role"], user["role"])
            
            log_security_event("LOGIN_SUCCESS", username, "Успешный вход в систему")
            return user
    
    log_security_event("LOGIN_FAILED", username, "Неудачная попытка входа")
    return None

def create_user(current_user):
    """Создает нового пользователя (для администратора)"""
    from database import load_data, save_data, get_default_permissions
    
    if not current_user.get("permissions", {}).get("manage_users", False):
        print("❌ Недостаточно прав для создания пользователей")
        return
    
    data = load_data()
    
    print("\n=== СОЗДАНИЕ НОВОГО ПОЛЬЗОВАТЕЛЯ ===")
    username = input("Логин: ")
    
    # Проверяем нет ли уже такого пользователя
    if any(user["username"] == username for user in data["users"]):
        print("❌ Пользователь с таким логином уже существует")
        return
    
    password = input("Пароль: ")
    full_name = input("ФИО: ")
    
    print("\nДоступные роли:")
    for role_key, role_name in ROLES.items():
        print(f"  {role_key} - {role_name}")
    
    role = input("Роль: ")
    
    if role not in ROLES:
        print("❌ Неверная роль")
        return
    
    user = {
        "username": username,
        "password": hash_password(password),
        "role": role,
        "full_name": full_name,
        "is_active": True,
        "permissions": get_default_permissions(role)
    }
    
    data["users"].append(user)
    save_data(data)
    
    print(f"✅ Пользователь {username} создан успешно!")
    log_security_event("USER_CREATED", current_user["username"], f"Создан пользователь: {username}")

def toggle_user_status(username, current_user):
    """Блокирует/разблокирует учетную запись пользователя"""
    from database import load_data, save_data
    
    if not current_user.get("permissions", {}).get("manage_users", False):
        print("❌ Недостаточно прав для управления пользователями")
        return False
    
    if username == current_user["username"]:
        print("❌ Нельзя заблокировать собственную учетную запись")
        return False
    
    data = load_data()
    
    for user in data["users"]:
        if user["username"] == username:
            user["is_active"] = not user.get("is_active", True)
            status = "разблокирован" if user["is_active"] else "заблокирован"
            save_data(data)
            
            log_security_event("USER_STATUS_CHANGED", current_user["username"], 
                             f"Пользователь {username} {status}")
            print(f"✅ Пользователь {username} {status}")
            return True
    
    print("❌ Пользователь не найден")
    return False

def audit_user_actions(action_type, user, entity_type, entity_id, description):
    """Аудит действий пользователя"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"{timestamp} - {action_type} - User: {user['username']} - Entity: {entity_type}:{entity_id} - {description}\n"
    
    with open("audit.log", "a", encoding="utf-8") as f:
        f.write(log_entry)

# Старая функция для обратной совместимости
def login_cli():
    """Функция для CLI входа (для обратной совместимости)"""
    return login()