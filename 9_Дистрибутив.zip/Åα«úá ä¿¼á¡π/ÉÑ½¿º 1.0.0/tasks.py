from database import load_data, save_data, TASK_STATUSES

def can_edit_task(task, user):
    """Проверяет можно ли редактировать задачу"""
    if user["permissions"].get("force_edit", False):
        return True
    
    # Получаем проект задачи
    data = load_data()
    project = next((p for p in data["projects"] if p["id"] == task["project_id"]), None)
    
    # Если проект закрыт, нельзя редактировать задачу
    if project and project["status"] in ["выполнено", "не_выполнено"]:
        return False
    
    return task["status"] in ["черновик", "на_рассмотрении"]

def create_task(user):
    if not user["permissions"].get("edit_tasks", False):
        print("❌ Доступ запрещен")
        return
    
    data = load_data()
    
    # Показываем доступные проекты
    print("Доступные проекты:")
    for project in data["projects"]:
        print(f"ID: {project['id']}, Название: {project['name']}")
    
    task = {
        "id": len(data["tasks"]) + 1,
        "project_id": int(input("ID проекта: ")),
        "title": input("Название задачи: "),
        "description": input("Описание: "),
        "deadline": input("Срок выполнения (ГГГГ-ММ-ДД): "),
        "priority": input("Приоритет: "),
        "responsible": user["username"],  # По умолчанию ответственный - текущий пользователь
        "status": "черновик",
        "custom_fields": {},
        "materials": []
    }
    
    data["tasks"].append(task)
    save_data(data)
    print("✅ Задача создана успешно!")


def show_task_details(task, data=None):
    """Показывает детали задачи (для CLI)"""
    if data is None:
        from database import load_data
        data = load_data()
    
    # Находим проект
    project = next((p for p in data["projects"] if p["id"] == task.get("project_id")), None)
    project_name = project.get("name", "Неизвестно") if project else "Неизвестно"
    
    print("\n=== ДЕТАЛИ ЗАДАЧИ ===")
    print(f"ID: {task.get('id', '')}")
    print(f"Название: {task.get('title', '')}")
    print(f"Статус: {task.get('status', 'черновик')}")
    print(f"Проект: {project_name}")
    print(f"Описание: {task.get('description', '')}")
    print(f"Ответственный: {task.get('responsible', '')}")
    print(f"Срок: {task.get('deadline', '')}")
    print(f"Приоритет: {task.get('priority', '')}")
    
    # Показываем работы задачи
    task_works = [w for w in data.get("works", []) if w.get("task_id") == task.get("id")]
    if task_works:
        print("\nРАБОТЫ ЗАДАЧИ:")
        for work in task_works:
            print(f"  - {work.get('title', '')} (Статус: {work.get('status', 'черновик')}, Исполнитель: {work.get('executor', '')})")
    else:
        print("\nРаботы не найдены")

def break_task_into_works(task_id, user):
    """Разбивает задачу на элементарные работы (для ответственного исполнителя)"""
    data = load_data()
    task = next((t for t in data["tasks"] if t["id"] == task_id), None)
    
    if not task:
        print("❌ Задача не найдена")
        return
    
    if task["responsible"] != user["username"] and not user["permissions"].get("force_edit", False):
        print("❌ Вы не являетесь ответственным исполнителем этой задачи")
        return
    
    print(f"Разбивка задачи '{task['title']}' на работы:")
    
    while True:
        work_name = input("Название работы (или 'стоп' для завершения): ")
        if work_name.lower() == 'стоп':
            break
        
        work = {
            "id": len(data.get("works", [])) + 1,
            "task_id": task_id,
            "title": work_name,
            "description": input("Описание работы: "),
            "parameters": "",  # Параметры убраны
            "executor": input("Исполнитель: "),
            "status": "черновик",
            "created_by": user["username"]
        }
        
        if "works" not in data:
            data["works"] = []
        data["works"].append(work)
        print("✅ Работа добавлена!")
    
    save_data(data)