from database import load_data, save_data, PROJECT_STATUSES

def can_edit_project(project, user):
    """Проверяет можно ли редактировать проект"""
    if user["permissions"].get("force_edit", False):
        return True
    return project["status"] in ["черновик", "на_рассмотрении"]

def can_change_project_status(project, new_status, user):
    """Проверяет можно ли изменить статус проекта"""
    if not user["permissions"].get("change_project_status", False):
        return False
    
    # Проверяем что все задачи завершены перед закрытием проекта
    if new_status in ["выполнено", "не_выполнено"]:
        data = load_data()
        project_tasks = [t for t in data["tasks"] if t["project_id"] == project["id"]]
        for task in project_tasks:
            if task["status"] not in ["выполнено", "не_выполнено"]:
                return False, f"Нельзя закрыть проект: задача '{task['title']}' не завершена"
    
    return True, ""

def create_project(user):
    if not user["permissions"].get("edit_projects", False):
        print("❌ Доступ запрещен")
        return
    
    data = load_data()
    project = {
        "id": len(data["projects"]) + 1,
        "name": input("Название проекта: "),
        "client": input("Заказчик: "),
        "start_date": input("Дата начала (ГГГГ-ММ-ДД): "),
        "planned_end": input("Плановая дата завершения (ГГГГ-ММ-ДД): "),
        "actual_end": "",
        "manager": user["username"],
        "cost": float(input("Стоимость проекта: ")),
        "status": "черновик",
        "custom_fields": {}
    }
    data["projects"].append(project)
    save_data(data)
    print("✅ Проект создан успешно!")

def edit_project(project_id, user):
    data = load_data()
    project = next((p for p in data["projects"] if p["id"] == project_id), None)
    
    if not project:
        print("❌ Проект не найден")
        return
    
    if not can_edit_project(project, user):
        print("❌ Редактирование запрещено: проект в статусе, не позволяющем редактирование")
        return
    
    print(f"Редактирование проекта: {project['name']}")
    print("Оставьте поле пустым чтобы сохранить текущее значение")
    
    new_name = input(f"Название [{project['name']}]: ")
    if new_name:
        project["name"] = new_name
    
    new_client = input(f"Заказчик [{project['client']}]: ")
    if new_client:
        project["client"] = new_client
    
    save_data(data)
    print("✅ Проект обновлен успешно!")

def change_project_status(project_id, new_status, user):
    data = load_data()
    project = next((p for p in data["projects"] if p["id"] == project_id), None)
    
    if not project:
        print("❌ Проект не найден")
        return
    
    can_change, message = can_change_project_status(project, new_status, user)
    if not can_change:
        print(f"❌ {message}")
        return
    
    old_status = project["status"]
    project["status"] = new_status
    
    # Если проект завершен, устанавливаем фактическую дату завершения
    if new_status in ["выполнено", "не_выполнено"]:
        from datetime import datetime
        project["actual_end"] = datetime.now().strftime("%Y-%m-%d")
    
    save_data(data)
    print(f"✅ Статус проекта изменен: {old_status} -> {new_status}")