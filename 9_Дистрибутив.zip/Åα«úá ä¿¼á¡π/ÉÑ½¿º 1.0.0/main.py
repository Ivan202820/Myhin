import sys
import os

def main():
    """Главная функция приложения"""
    try:
        print("=== СИСТЕМА УПРАВЛЕНИЯ ПРОЕКТАМИ ===")
        print("Загрузка стартового меню...")
        
        # Импортируем здесь, чтобы избежать циклических импортов
        from start_menu import main as start_main
        start_main()
        
    except KeyboardInterrupt:
        print("\nПрограмма завершена пользователем")
    except Exception as e:
        print(f"Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()
        input("Нажмите Enter для выхода...")
        sys.exit(1)

if __name__ == "__main__":
    main()