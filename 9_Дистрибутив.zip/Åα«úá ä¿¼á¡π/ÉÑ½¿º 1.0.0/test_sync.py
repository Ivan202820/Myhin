# test_sync.py
from db_sync_manager import check_and_sync_on_startup, sync_manager

if __name__ == "__main__":
    print("Тестирование синхронизации...")
    
    # Проверка и синхронизация
    check_and_sync_on_startup()
    
    # Ручная синхронизация
    input("\nНажмите Enter для ручной синхронизации...")
    sync_manager.manual_sync('both')
    
    # Остановка
    input("\nНажмите Enter для остановки...")
    sync_manager.stop_auto_sync()