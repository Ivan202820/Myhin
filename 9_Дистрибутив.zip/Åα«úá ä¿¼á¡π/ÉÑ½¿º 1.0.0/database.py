# database.py
import json
import os
from datetime import datetime

DB_FILE = "data.json"

def load_data():
    """Загрузка данных из JSON файла"""
    if not os.path.exists(DB_FILE):
        # Создаем файл с данными по умолчанию
        default_data = {
            'users': [],
            'projects': [],
            'tasks': [],
            'works': [],
            'notifications': []
        }
        save_data(default_data)
        return default_data
    
    try:
        with open(DB_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        print(f"Ошибка декодирования JSON: {e}")
        # Возвращаем данные по умолчанию
        return {
            'users': [],
            'projects': [],
            'tasks': [],
            'works': [],
            'notifications': []
        }
    except Exception as e:
        print(f"Ошибка загрузки данных: {e}")
        # Возвращаем данные по умолчанию
        return {
            'users': [],
            'projects': [],
            'tasks': [],
            'works': [],
            'notifications': []
        }

def save_data(data):
    """Сохранение данных в JSON файл"""
    try:
        with open(DB_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Ошибка сохранения данных: {e}")
        return False

def save_data_with_sync(data):
    """Сохраняет данные в JSON и запускает синхронизацию"""
    try:
        # Сохраняем в JSON
        with open(DB_FILE, "w", encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        # Запускаем синхронизацию в фоновом режиме
        try:
            from db_sync_manager import sync_manager
            if sync_manager.test_connection():
                # Запускаем синхронизацию в отдельном потоке
                import threading
                def sync_in_background():
                    try:
                        sync_manager.sync_json_to_postgres()
                    except:
                        pass
                
                thread = threading.Thread(target=sync_in_background, daemon=True)
                thread.start()
        except:
            pass  # Игнорируем ошибки синхронизации
        
        return True
    except Exception as e:
        print(f"Ошибка сохранения данных: {e}")
        return False

def get_user_by_username(username):
    """Получение пользователя по имени пользователя"""
    try:
        data = load_data()
        users = data.get('users', [])
        for user in users:
            if user.get('username') == username:
                return user
        return None
    except Exception as e:
        print(f"Ошибка при получении пользователя: {e}")
        return None

def get_projects():
    """Получение всех проектов"""
    try:
        data = load_data()
        return data.get('projects', [])
    except Exception as e:
        print(f"Ошибка при получении проектов: {e}")
        return []

def get_tasks():
    """Получение всех задач"""
    try:
        data = load_data()
        return data.get('tasks', [])
    except Exception as e:
        print(f"Ошибка при получении задач: {e}")
        return []

def get_works():
    """Получение всех работ"""
    try:
        data = load_data()
        return data.get('works', [])
    except Exception as e:
        print(f"Ошибка при получении работ: {e}")
        return []

def get_notifications_for_user(username):
    """Получение уведомлений для пользователя"""
    try:
        data = load_data()
        notifications = data.get('notifications', [])
        user_notifications = []
        for notification in notifications:
            if notification.get('user') == username and not notification.get('read', False):
                user_notifications.append(notification)
        return user_notifications
    except Exception as e:
        print(f"Ошибка при получении уведомлений: {e}")
        return []

def update_user(username, updated_data):
    """Обновление данных пользователя"""
    try:
        data = load_data()
        users = data.get('users', [])
        
        for i, user in enumerate(users):
            if user.get('username') == username:
                # Сохраняем важные поля
                updated_data['username'] = username
                if 'password' not in updated_data:
                    updated_data['password'] = user.get('password', '')
                
                users[i] = updated_data
                data['users'] = users
                save_data_with_sync(data)
                return True
        
        return False
    except Exception as e:
        print(f"Ошибка при обновлении пользователя: {e}")
        return False
# database.py (добавьте после существующих функций)

def get_default_permissions(role):
    """Получение прав по умолчанию для роли"""
    default_permissions = {
        'администратор': {
            'view_projects': True,
            'edit_projects': True,
            'delete_projects': True,
            'change_project_status': True,
            'view_tasks': True,
            'edit_tasks': True,
            'delete_tasks': True,
            'change_task_status': True,
            'view_works': True,
            'edit_works': True,
            'change_work_status': True,
            'manage_users': True,
            'view_reports': True,
            'edit_reports': True,
            'force_edit': True,
            'manage_attachments': True
        },
        'руководитель_проекта': {
            'view_projects': True,
            'edit_projects': True,
            'delete_projects': False,
            'change_project_status': True,
            'view_tasks': True,
            'edit_tasks': True,
            'delete_tasks': False,
            'change_task_status': True,
            'view_works': True,
            'edit_works': False,
            'change_work_status': False,
            'manage_users': False,
            'view_reports': True,
            'edit_reports': True,
            'force_edit': False,
            'manage_attachments': True
        },
        'ответственный_исполнитель': {
            'view_projects': True,
            'edit_projects': False,
            'delete_projects': False,
            'change_project_status': False,
            'view_tasks': True,
            'edit_tasks': True,
            'delete_tasks': False,
            'change_task_status': True,
            'view_works': True,
            'edit_works': True,
            'change_work_status': True,
            'manage_users': False,
            'view_reports': True,
            'edit_reports': False,
            'force_edit': False,
            'manage_attachments': True
        },
        'исполнитель': {
            'view_projects': True,
            'edit_projects': False,
            'delete_projects': False,
            'change_project_status': False,
            'view_tasks': True,
            'edit_tasks': False,
            'delete_tasks': False,
            'change_task_status': False,
            'view_works': True,
            'edit_works': False,
            'change_work_status': True,
            'manage_users': False,
            'view_reports': False,
            'edit_reports': False,
            'force_edit': False,
            'manage_attachments': False
        }
    }
    
    # Возвращаем права для роли или права исполнителя по умолчанию
    return default_permissions.get(role, default_permissions['исполнитель'])

def create_user(username, password, role, full_name, is_active=True):
    """Создание нового пользователя"""
    try:
        data = load_data()
        
        # Проверяем, существует ли пользователь
        for user in data['users']:
            if user['username'] == username:
                return False, "Пользователь с таким логином уже существует"
        
        # Создаем нового пользователя
        new_user = {
            'username': username,
            'password': password,
            'role': role,
            'full_name': full_name,
            'permissions': get_default_permissions(role),
            'is_active': is_active
        }
        
        data['users'].append(new_user)
        
        if save_data_with_sync(data):
            return True, "Пользователь успешно создан"
        else:
            return False, "Ошибка при сохранении данных"
            
    except Exception as e:
        return False, f"Ошибка при создании пользователя: {str(e)}"

def delete_user(username):
    """Удаление пользователя"""
    try:
        data = load_data()
        
        # Находим пользователя
        user_index = -1
        for i, user in enumerate(data['users']):
            if user['username'] == username:
                user_index = i
                break
        
        if user_index == -1:
            return False, "Пользователь не найден"
        
        # Не позволяем удалить последнего администратора
        if data['users'][user_index]['role'] == 'администратор':
            admin_count = sum(1 for user in data['users'] if user['role'] == 'администратор')
            if admin_count <= 1:
                return False, "Нельзя удалить последнего администратора"
        
        # Удаляем пользователя
        data['users'].pop(user_index)
        
        if save_data_with_sync(data):
            return True, "Пользователь успешно удален"
        else:
            return False, "Ошибка при сохранении данных"
            
    except Exception as e:
        return False, f"Ошибка при удалении пользователя: {str(e)}"

def get_all_users():
    """Получение всех пользователей"""
    try:
        data = load_data()
        return data.get('users', [])
    except Exception as e:
        print(f"Ошибка при получении пользователей: {e}")
        return []

def update_user_permissions(username, permissions):
    """Обновление прав пользователя"""
    try:
        data = load_data()
        
        for user in data['users']:
            if user['username'] == username:
                user['permissions'] = permissions
                if save_data_with_sync(data):
                    return True, "Права пользователя обновлены"
                else:
                    return False, "Ошибка при сохранении данных"
        
        return False, "Пользователь не найден"
            
    except Exception as e:
        return False, f"Ошибка при обновлении прав: {str(e)}"

def check_permission(username, permission):
    """Проверка прав пользователя"""
    try:
        user = get_user_by_username(username)
        if not user:
            return False
        
        # Если пользователь не активен, нет прав
        if not user.get('is_active', True):
            return False
        
        # Получаем права
        user_permissions = user.get('permissions', {})
        
        # Проверяем конкретное право
        return user_permissions.get(permission, False)
        
    except Exception as e:
        print(f"Ошибка при проверке прав: {e}")
        return False
