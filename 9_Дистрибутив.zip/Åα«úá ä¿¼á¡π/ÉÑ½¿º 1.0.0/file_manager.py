import os
import shutil
import hashlib
from datetime import datetime

ATTACHMENTS_DIR = "attachments"

def ensure_attachments_dir():
    """Создает директорию для вложений если ее нет"""
    if not os.path.exists(ATTACHMENTS_DIR):
        os.makedirs(ATTACHMENTS_DIR)

def save_attachment(file_path, entity_type, entity_id):
    """Сохраняет файл в систему вложений"""
    ensure_attachments_dir()
    
    if not os.path.exists(file_path):
        return None
    
    # Генерируем уникальное имя файла
    file_ext = os.path.splitext(file_path)[1]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_hash = hashlib.md5(f"{entity_type}_{entity_id}_{timestamp}".encode()).hexdigest()[:8]
    new_filename = f"{entity_type}_{entity_id}_{file_hash}{file_ext}"
    new_filepath = os.path.join(ATTACHMENTS_DIR, new_filename)
    
    try:
        shutil.copy2(file_path, new_filepath)
        return new_filename
    except Exception as e:
        print(f"❌ Ошибка при сохранении файла: {e}")
        return None

def get_attachment_path(filename):
    """Возвращает полный путь к файлу вложения"""
    return os.path.join(ATTACHMENTS_DIR, filename) if filename else None

def delete_attachment(filename):
    """Удаляет файл вложения"""
    if filename and os.path.exists(os.path.join(ATTACHMENTS_DIR, filename)):
        try:
            os.remove(os.path.join(ATTACHMENTS_DIR, filename))
            return True
        except Exception as e:
            print(f"❌ Ошибка при удалении файла: {e}")
    return False

def get_attachment_info(filename):
    """Возвращает информацию о файле"""
    if not filename:
        return None
    
    filepath = os.path.join(ATTACHMENTS_DIR, filename)
    if os.path.exists(filepath):
        stat = os.stat(filepath)
        return {
            "filename": filename,
            "size": stat.st_size,
            "created": datetime.fromtimestamp(stat.st_ctime),
            "path": filepath
        }
    return None