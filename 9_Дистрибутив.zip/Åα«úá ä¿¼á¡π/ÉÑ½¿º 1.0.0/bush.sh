python -m venv venv
venv\Scripts\activate    # Windows