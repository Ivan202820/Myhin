# db_sync_manager.py
import psycopg2
import json
import os
import sys
from datetime import datetime, date
import threading
import time
import traceback

# Конфигурация подключения к PostgreSQL
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "project_management_db",
    "user": "postgres",
    "password": "0"  # Пароль, который вы задали при установке PostgreSQL
}

class DateTimeEncoder(json.JSONEncoder):
    """Кастомный JSON энкодер для обработки datetime и date объектов"""
    
    def default(self, obj):
        if isinstance(obj, (datetime, date)):
            if isinstance(obj, datetime):
                return obj.strftime('%Y-%m-%d %H:%M:%S')
            else:
                return obj.strftime('%Y-%m-%d')
        # Для всех остальных типов вызываем родительский метод
        return super().default(obj)

class DatabaseSyncManager:
    """Менеджер синхронизации между JSON и PostgreSQL"""
    
    def __init__(self, json_file="data.json"):
        self.json_file = json_file
        self.last_sync_time = None
        self.is_syncing = False
        self.sync_interval = 300  # Синхронизация каждые 5 минут (в секундах)
        self.sync_thread = None
        self.stop_sync = False
        
    def test_connection(self):
        """Проверка подключения к PostgreSQL"""
        try:
            conn = psycopg2.connect(**DB_CONFIG)
            conn.close()
            return True
        except Exception as e:
            print(f"⚠️  PostgreSQL недоступен: {e}")
            print("Продолжение работы с локальным JSON файлом...")
            return False
    
    def load_json_data(self):
        """Загрузка данных из JSON файла с улучшенной обработкой ошибок"""
        try:
            with open(self.json_file, 'r', encoding='utf-8') as f:
                content = f.read()
                if not content.strip():
                    print("⚠️  JSON файл пустой")
                    return self._create_default_data()
                
                try:
                    return json.loads(content)
                except json.JSONDecodeError as e:
                    print(f"❌ Ошибка парсинга JSON файла: {e}")
                    print("Попытка восстановления данных...")
                    return self._repair_json_file(content)
                    
        except FileNotFoundError:
            print(f"⚠️  JSON файл не найден: {self.json_file}")
            return self._create_default_data()
        except Exception as e:
            print(f"❌ Ошибка загрузки JSON файла: {e}")
            return self._create_default_data()
    
    def _create_default_data(self):
        """Создание данных по умолчанию"""
        print("📝 Создание данных по умолчанию...")
        default_data = {
            'users': [],
            'projects': [],
            'tasks': [],
            'works': [],
            'notifications': []
        }
        return default_data
    
    def _repair_json_file(self, content):
        """Попытка восстановить поврежденный JSON файл"""
        try:
            # Пробуем найти и исправить распространенные проблемы
            # 1. Убираем лишние запятые в конце объектов/массивов
            import re
            # Убираем запятые перед закрывающими скобками
            content = re.sub(r',\s*}', '}', content)
            content = re.sub(r',\s*]', ']', content)
            
            # 2. Проверяем на незакрытые кавычки
            quote_count = content.count('"')
            if quote_count % 2 != 0:
                print("⚠️  Обнаружены незакрытые кавычки, добавляем...")
                content = content + '"'
            
            # 3. Пробуем распарсить снова
            data = json.loads(content)
            print("✅ JSON файл восстановлен")
            return data
            
        except Exception as e:
            print(f"❌ Не удалось восстановить JSON файл: {e}")
            # Создаем резервную копию поврежденного файла
            backup_file = f"{self.json_file}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            try:
                with open(backup_file, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"📁 Создана резервная копия поврежденного файла: {backup_file}")
            except:
                pass
            return self._create_default_data()
    
    def save_json_data(self, data):
        """Сохранение данных в JSON файл"""
        try:
            # Сначала сохраняем в временный файл
            temp_file = self.json_file + ".tmp"
            with open(temp_file, 'w', encoding='utf-8') as f:
                # Используем кастомный энкодер для обработки дат
                json.dump(data, f, indent=2, ensure_ascii=False, cls=DateTimeEncoder)
            
            # Проверяем, что временный файл валидный
            with open(temp_file, 'r', encoding='utf-8') as f:
                json.load(f)  # Если ошибка - будет исключение
            
            # Если все ок - заменяем оригинальный файл
            os.replace(temp_file, self.json_file)
            return True
            
        except json.JSONDecodeError as e:
            print(f"❌ Ошибка проверки JSON файла: {e}")
            # Удаляем временный файл
            if os.path.exists(temp_file):
                os.remove(temp_file)
            return False
        except Exception as e:
            print(f"❌ Ошибка сохранения JSON файла: {e}")
            # Удаляем временный файл
            if os.path.exists(temp_file):
                os.remove(temp_file)
            return False
    
    def sync_json_to_postgres(self):
        """Синхронизация из JSON в PostgreSQL"""
        if self.is_syncing:
            return False
            
        self.is_syncing = True
        print("🔄 Синхронизация JSON → PostgreSQL...")
        
        try:
            # Загружаем данные из JSON
            data = self.load_json_data()
            if not data:
                print("❌ Нет данных для синхронизации")
                return False
            
            # Проверяем структуру данных
            if not self._validate_data_structure(data):
                print("❌ Некорректная структура данных")
                return False
            
            # Подключаемся к БД
            conn = psycopg2.connect(**DB_CONFIG)
            conn.autocommit = False
            
            # Синхронизируем данные
            success = self._sync_all_tables(conn, data)
            
            if success:
                self.last_sync_time = datetime.now()
                print("✅ Синхронизация JSON → PostgreSQL завершена успешно")
            else:
                print("❌ Синхронизация JSON → PostgreSQL не удалась")
            
            conn.close()
            return success
            
        except Exception as e:
            print(f"❌ Ошибка синхронизации JSON → PostgreSQL: {e}")
            traceback.print_exc()
            return False
        finally:
            self.is_syncing = False
    
    def _validate_data_structure(self, data):
        """Проверка структуры данных"""
        required_keys = ['users', 'projects', 'tasks', 'works', 'notifications']
        for key in required_keys:
            if key not in data:
                print(f"❌ Отсутствует обязательный ключ: {key}")
                return False
            if not isinstance(data[key], list):
                print(f"❌ Ключ {key} должен быть списком, а не {type(data[key])}")
                return False
        return True
    
    def sync_postgres_to_json(self):
        """Синхронизация из PostgreSQL в JSON"""
        if self.is_syncing:
            return False
            
        self.is_syncing = True
        print("🔄 Синхронизация PostgreSQL → JSON...")
        
        try:
            # Подключаемся к БД
            conn = psycopg2.connect(**DB_CONFIG)
            
            # Загружаем данные из всех таблиц
            data = self._load_all_from_postgres(conn)
            
            if data:
                # Сохраняем в JSON
                if self.save_json_data(data):
                    self.last_sync_time = datetime.now()
                    print("✅ Синхронизация PostgreSQL → JSON завершена успешно")
                    success = True
                else:
                    print("❌ Ошибка сохранения данных в JSON")
                    success = False
            else:
                print("❌ Не удалось загрузить данные из PostgreSQL")
                success = False
            
            conn.close()
            return success
            
        except Exception as e:
            print(f"❌ Ошибка синхронизации PostgreSQL → JSON: {e}")
            traceback.print_exc()
            return False
        finally:
            self.is_syncing = False
    
    def _sync_all_tables(self, conn, data):
        """Синхронизация всех таблиц"""
        try:
            # Синхронизируем в правильном порядке (с учетом внешних ключей)
            cur = conn.cursor()
            
            # 1. Пользователи
            print("  📋 Синхронизация пользователей...")
            self._sync_table(conn, cur, 'users', data.get('users', []), 
                           ['username', 'password', 'role', 'full_name', 'permissions', 'is_active'])
            
            # 2. Проекты
            print("  📋 Синхронизация проектов...")
            self._sync_table(conn, cur, 'projects', data.get('projects', []),
                           ['id', 'name', 'client', 'start_date', 'planned_end', 'actual_end',
                            'manager', 'cost', 'status', 'custom_fields', 'attachments'])
            
            # 3. Задачи
            print("  📋 Синхронизация задач...")
            self._sync_table(conn, cur, 'tasks', data.get('tasks', []),
                           ['id', 'project_id', 'title', 'description', 'deadline', 'priority',
                            'responsible', 'status', 'custom_fields', 'materials', 'attachments'])
            
            # 4. Работы
            print("  📋 Синхронизация работ...")
            self._sync_table(conn, cur, 'works', data.get('works', []),
                           ['id', 'task_id', 'title', 'description', 'parameters',
                            'executor', 'status', 'created_by', 'attachments'])
            
            # 5. Уведомления
            print("  📋 Синхронизация уведомлений...")
            self._sync_table(conn, cur, 'notifications', data.get('notifications', []),
                           ['id', 'user', 'type', 'message', 'date', 'read'])
            
            conn.commit()
            return True
            
        except Exception as e:
            conn.rollback()
            print(f"❌ Ошибка синхронизации таблиц: {e}")
            traceback.print_exc()
            return False
    
    def _sync_table(self, conn, cur, table_name, data, columns):
        """Синхронизация одной таблицы"""
        if not data:
            return
        
        # Определяем первичный ключ для каждой таблицы
        primary_key_map = {
            'users': 'username',
            'projects': 'id',
            'tasks': 'id',
            'works': 'id',
            'notifications': 'id'
        }
        
        primary_key = primary_key_map.get(table_name, 'id')
        
        # Специальная обработка для notifications (изменяем user -> user_username)
        if table_name == 'notifications':
            columns = ['id', 'user_username', 'type', 'message', 'date', 'is_read']
        
        placeholders = ', '.join(['%s'] * len(columns))
        col_names = ', '.join(columns)
        update_cols = ', '.join([f"{col} = EXCLUDED.{col}" for col in columns if col != primary_key])
        
        for record in data:
            try:
                # Проверяем запись на валидность
                if not isinstance(record, dict):
                    print(f"    ⚠️  Пропускаем невалидную запись (не словарь) в таблице {table_name}")
                    continue
                
                # Подготавливаем значения
                values = []
                for col in columns:
                    # Преобразуем для notifications
                    if table_name == 'notifications':
                        if col == 'user_username':
                            val = record.get('user')
                        elif col == 'is_read':
                            val = record.get('read', False)
                        else:
                            val = record.get(col)
                    else:
                        val = record.get(col)
                    
                    # Обработка пустых дат для PostgreSQL
                    if col in ['actual_end', 'start_date', 'planned_end', 'deadline', 'date']:
                        if val == "" or val is None:
                            val = None  # NULL для PostgreSQL
                        elif isinstance(val, str):
                            # Проверяем, что это валидная дата
                            try:
                                # Преобразуем строку в datetime для проверки
                                datetime.strptime(val, '%Y-%m-%d')
                            except ValueError:
                                # Проверяем формат с временем
                                try:
                                    datetime.strptime(val, '%Y-%m-%d %H:%M:%S')
                                except ValueError:
                                    val = None  # Если невалидная дата - устанавливаем NULL
                    
                    # Преобразуем словари/списки в JSON
                    if isinstance(val, (dict, list)):
                        val = json.dumps(val, ensure_ascii=False)
                    
                    # Для булевых значений
                    if col == 'is_active' and val is None:
                        val = True
                    
                    values.append(val)
                
                # Вставляем или обновляем запись
                query = f"""
                    INSERT INTO {table_name} ({col_names})
                    VALUES ({placeholders})
                    ON CONFLICT ({primary_key}) DO UPDATE SET
                        {update_cols},
                        updated_at = CURRENT_TIMESTAMP
                """
                cur.execute(query, values)
                
            except Exception as e:
                print(f"    ⚠️ Ошибка записи в таблицу {table_name} (запись: {record.get(primary_key, 'unknown')}): {e}")
                # Продолжаем с другими записями
                continue
    
    def _load_all_from_postgres(self, conn):
        """Загрузка всех данных из PostgreSQL"""
        try:
            data = {
                'users': [],
                'projects': [],
                'tasks': [],
                'works': [],
                'notifications': []
            }
            
            cur = conn.cursor()
            
            # Загружаем пользователей
            cur.execute("SELECT username, password, role, full_name, permissions, is_active FROM users")
            for row in cur.fetchall():
                permissions = row[4]
                # Проверяем, нужно ли декодировать JSON
                if isinstance(permissions, str):
                    try:
                        permissions = json.loads(permissions) if permissions else {}
                    except:
                        permissions = {}
                
                data['users'].append({
                    'username': row[0],
                    'password': row[1],
                    'role': row[2],
                    'full_name': row[3],
                    'permissions': permissions,
                    'is_active': row[5]
                })
            
            # Загружаем проекты
            cur.execute("""
                SELECT id, name, client, start_date, planned_end, actual_end, 
                       manager, cost, status, custom_fields, attachments 
                FROM projects
            """)
            for row in cur.fetchall():
                custom_fields = row[9]
                attachments = row[10]
                
                if isinstance(custom_fields, str):
                    try:
                        custom_fields = json.loads(custom_fields) if custom_fields else {}
                    except:
                        custom_fields = {}
                
                if isinstance(attachments, str):
                    try:
                        attachments = json.loads(attachments) if attachments else []
                    except:
                        attachments = []
                
                # Преобразуем даты в строки
                start_date = row[3]
                planned_end = row[4]
                actual_end = row[5]
                
                if isinstance(start_date, (datetime, date)):
                    start_date = start_date.strftime('%Y-%m-%d')
                elif start_date is None:
                    start_date = ""
                    
                if isinstance(planned_end, (datetime, date)):
                    planned_end = planned_end.strftime('%Y-%m-%d')
                elif planned_end is None:
                    planned_end = ""
                    
                if isinstance(actual_end, (datetime, date)):
                    actual_end = actual_end.strftime('%Y-%m-%d')
                elif actual_end is None:
                    actual_end = ""
                
                data['projects'].append({
                    'id': row[0],
                    'name': row[1],
                    'client': row[2],
                    'start_date': start_date,
                    'planned_end': planned_end,
                    'actual_end': actual_end,
                    'manager': row[6],
                    'cost': float(row[7]) if row[7] else 0.0,
                    'status': row[8],
                    'custom_fields': custom_fields,
                    'attachments': attachments
                })
            
            # Загружаем задачи
            cur.execute("""
                SELECT id, project_id, title, description, deadline, priority,
                       responsible, status, custom_fields, materials, attachments
                FROM tasks
            """)
            for row in cur.fetchall():
                custom_fields = row[8]
                materials = row[9]
                attachments = row[10]
                
                if isinstance(custom_fields, str):
                    try:
                        custom_fields = json.loads(custom_fields) if custom_fields else {}
                    except:
                        custom_fields = {}
                
                if isinstance(materials, str):
                    try:
                        materials = json.loads(materials) if materials else []
                    except:
                        materials = []
                
                if isinstance(attachments, str):
                    try:
                        attachments = json.loads(attachments) if attachments else []
                    except:
                        attachments = []
                
                # Преобразуем даты в строки
                deadline = row[4]
                if isinstance(deadline, (datetime, date)):
                    deadline = deadline.strftime('%Y-%m-%d')
                elif deadline is None:
                    deadline = ""
                
                data['tasks'].append({
                    'id': row[0],
                    'project_id': row[1],
                    'title': row[2],
                    'description': row[3],
                    'deadline': deadline,
                    'priority': row[5],
                    'responsible': row[6],
                    'status': row[7],
                    'custom_fields': custom_fields,
                    'materials': materials,
                    'attachments': attachments
                })
            
            # Загружаем работы
            cur.execute("""
                SELECT id, task_id, title, description, parameters,
                       executor, status, created_by, attachments
                FROM works
            """)
            for row in cur.fetchall():
                attachments = row[8]
                
                if isinstance(attachments, str):
                    try:
                        attachments = json.loads(attachments) if attachments else []
                    except:
                        attachments = []
                
                data['works'].append({
                    'id': row[0],
                    'task_id': row[1],
                    'title': row[2],
                    'description': row[3],
                    'parameters': row[4],
                    'executor': row[5],
                    'status': row[6],
                    'created_by': row[7],
                    'attachments': attachments
                })
            
            # Загружаем уведомления
            cur.execute("""
                SELECT id, user_username, type, message, date, is_read
                FROM notifications
            """)
            for row in cur.fetchall():
                # Преобразуем даты в строки
                date_val = row[4]
                if isinstance(date_val, datetime):
                    date_val = date_val.strftime('%Y-%m-%d %H:%M:%S')
                elif isinstance(date_val, date):
                    date_val = date_val.strftime('%Y-%m-%d')
                elif date_val is None:
                    date_val = ""
                
                data['notifications'].append({
                    'id': row[0],
                    'user': row[1],
                    'type': row[2],
                    'message': row[3],
                    'date': date_val,
                    'read': row[5]
                })
            
            return data
            
        except Exception as e:
            print(f"❌ Ошибка загрузки данных из PostgreSQL: {e}")
            traceback.print_exc()
            return None
    
    def start_auto_sync(self):
        """Запуск автоматической синхронизации в фоновом режиме"""
        if self.sync_thread and self.sync_thread.is_alive():
            return
        
        self.stop_sync = False
        self.sync_thread = threading.Thread(target=self._sync_loop, daemon=True)
        self.sync_thread.start()
        print("🚀 Фоновая синхронизация запущена")
    
    def stop_auto_sync(self):
        """Остановка автоматической синхронизации"""
        self.stop_sync = True
        if self.sync_thread:
            self.sync_thread.join(timeout=5)
        print("⏹️  Фоновая синхронизация остановлена")
    
    def _sync_loop(self):
        """Цикл фоновой синхронизации"""
        while not self.stop_sync:
            try:
                # Ждем интервал
                time.sleep(self.sync_interval)
                
                # Проверяем доступность PostgreSQL
                if self.test_connection():
                    # Синхронизируем в обе стороны
                    self.sync_json_to_postgres()
                    # Небольшая пауза между операциями
                    time.sleep(1)
                    self.sync_postgres_to_json()
                    
            except Exception as e:
                print(f"⚠️  Ошибка в цикле синхронизации: {e}")
    
    def manual_sync(self, direction='both'):
        """Ручная синхронизация"""
        if direction == 'both' or direction == 'to_postgres':
            print("🔄 Запуск синхронизации JSON → PostgreSQL...")
            self.sync_json_to_postgres()
        
        if direction == 'both' or direction == 'to_json':
            time.sleep(1)  # Небольшая пауза
            print("🔄 Запуск синхронизации PostgreSQL → JSON...")
            self.sync_postgres_to_json()
    
    def check_json_file(self):
        """Проверка целостности JSON файла"""
        try:
            with open(self.json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"✅ JSON файл валиден")
                print(f"   Пользователей: {len(data.get('users', []))}")
                print(f"   Проектов: {len(data.get('projects', []))}")
                print(f"   Задач: {len(data.get('tasks', []))}")
                print(f"   Работ: {len(data.get('works', []))}")
                print(f"   Уведомлений: {len(data.get('notifications', []))}")
                return True
        except Exception as e:
            print(f"❌ JSON файл поврежден: {e}")
            return False

# Глобальный экземпляр менеджера синхронизации
sync_manager = DatabaseSyncManager()

def init_sync_manager():
    """Инициализация менеджера синхронизации"""
    return sync_manager

def check_and_sync_on_startup():
    """Проверка и синхронизация при запуске программы"""
    print("\n" + "="*50)
    print("ПРОВЕРКА СИНХРОНИЗАЦИИ БАЗЫ ДАННЫХ")
    print("="*50)
    
    # Сначала проверяем JSON файл
    print("\n📁 Проверка JSON файла...")
    if not sync_manager.check_json_file():
        print("⚠️  Обнаружены проблемы с JSON файлом")
    
    # Проверяем подключение к PostgreSQL
    if sync_manager.test_connection():
        print("✅ Подключение к PostgreSQL установлено")
        
        # Синхронизируем при запуске (только из PostgreSQL в JSON если JSON поврежден)
        print("\n🔄 Выполнение начальной синхронизации...")
        
        # Пробуем сначала синхронизировать из JSON в PostgreSQL
        success1 = sync_manager.sync_json_to_postgres()
        
        # Пауза
        time.sleep(1)
        
        # Затем из PostgreSQL в JSON
        success2 = sync_manager.sync_postgres_to_json()
        
        # Запускаем фоновую синхронизацию
        if success1 or success2:
            sync_manager.start_auto_sync()
        return True
    else:
        print("⚠️  PostgreSQL недоступен. Работа с локальным JSON файлом.")
        return False

def get_sync_status():
    """Получение статуса синхронизации"""
    status = {
        'postgres_available': sync_manager.test_connection(),
        'last_sync_time': sync_manager.last_sync_time,
        'is_syncing': sync_manager.is_syncing,
        'sync_interval': sync_manager.sync_interval
    }
    return status

def repair_json_file():
    """Ручное восстановление JSON файла"""
    print("🔧 Ручное восстановление JSON файла...")
    data = sync_manager.load_json_data()
    if data and sync_manager.save_json_data(data):
        print("✅ JSON файл восстановлен")
        return True
    else:
        print("❌ Не удалось восстановить JSON файл")
        return False