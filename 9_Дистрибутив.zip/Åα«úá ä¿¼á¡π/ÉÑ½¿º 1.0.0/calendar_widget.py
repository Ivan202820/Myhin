import tkinter as tk
from tkinter import ttk
from datetime import datetime, timedelta
import calendar

class CalendarDialog:
    def __init__(self, parent, current_date=None):
        self.top = tk.Toplevel(parent)
        self.top.title("Выбор даты")
        self.top.geometry("300x300")
        self.top.transient(parent)
        self.top.grab_set()
        
        self.result = None
        self.current_date = current_date or datetime.now()
        
        self.setup_calendar()
        
    def setup_calendar(self):
        # Заголовок с месяцем и годом
        header_frame = ttk.Frame(self.top)
        header_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.prev_btn = ttk.Button(header_frame, text="◀", width=3, command=self.prev_month)
        self.prev_btn.pack(side=tk.LEFT)
        
        self.month_label = ttk.Label(header_frame, text="", font=('Arial', 12, 'bold'))
        self.month_label.pack(side=tk.LEFT, expand=True)
        
        self.next_btn = ttk.Button(header_frame, text="▶", width=3, command=self.next_month)
        self.next_btn.pack(side=tk.RIGHT)
        
        # Дни недели
        days_frame = ttk.Frame(self.top)
        days_frame.pack(fill=tk.X, padx=10, pady=2)
        
        days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
        for day in days:
            label = ttk.Label(days_frame, text=day, width=4, font=('Arial', 9))
            label.pack(side=tk.LEFT)
        
        # Календарь
        self.calendar_frame = ttk.Frame(self.top)
        self.calendar_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Кнопки управления
        btn_frame = ttk.Frame(self.top)
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Button(btn_frame, text="Сегодня", command=self.set_today).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Отмена", command=self.top.destroy).pack(side=tk.RIGHT, padx=5)
        ttk.Button(btn_frame, text="OK", command=self.select_date).pack(side=tk.RIGHT, padx=5)
        
        self.update_calendar()
    
    def update_calendar(self):
        # Обновляем заголовок
        month_names = [
            "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
            "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
        ]
        self.month_label.config(text=f"{month_names[self.current_date.month-1]} {self.current_date.year}")
        
        # Очищаем календарь
        for widget in self.calendar_frame.winfo_children():
            widget.destroy()
        
        # Создаем календарь на текущий месяц
        cal = calendar.monthcalendar(self.current_date.year, self.current_date.month)
        
        self.day_buttons = []
        for week_num, week in enumerate(cal):
            for day_num, day in enumerate(week):
                if day != 0:
                    btn = ttk.Button(
                        self.calendar_frame, 
                        text=str(day), 
                        width=4,
                        command=lambda d=day: self.set_selected_day(d)
                    )
                    btn.grid(row=week_num, column=day_num, padx=1, pady=1)
                    self.day_buttons.append(btn)
                    
                    # Подсвечиваем сегодняшний день
                    today = datetime.now()
                    if (day == today.day and 
                        self.current_date.month == today.month and 
                        self.current_date.year == today.year):
                        btn.configure(style='Today.TButton')
    
    def set_selected_day(self, day):
        self.selected_date = datetime(self.current_date.year, self.current_date.month, day)
        self.select_date()
    
    def set_today(self):
        self.selected_date = datetime.now()
        self.select_date()
    
    def select_date(self):
        if hasattr(self, 'selected_date'):
            self.result = self.selected_date.strftime("%Y-%m-%d")
        self.top.destroy()
    
    def prev_month(self):
        self.current_date = self.current_date.replace(day=1) - timedelta(days=1)
        self.update_calendar()
    
    def next_month(self):
        next_month = self.current_date.month + 1
        next_year = self.current_date.year
        if next_month > 12:
            next_month = 1
            next_year += 1
        self.current_date = self.current_date.replace(year=next_year, month=next_month, day=1)
        self.update_calendar()

def create_calendar_style():
    """Создает стиль для календаря"""
    style = ttk.Style()
    style.configure('Today.TButton', background='#e6f3ff', foreground='blue')

# Функция для удобного использования
def ask_date(parent, current_date=None):
    """Открывает диалог выбора даты и возвращает выбранную дату в формате YYYY-MM-DD"""
    create_calendar_style()
    dialog = CalendarDialog(parent, current_date)
    parent.wait_window(dialog.top)
    return dialog.result